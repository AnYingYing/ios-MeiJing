//
//  MineController.m
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "MineController.h"
//定义宽度和高度
#define kScreenWidth    [UIScreen mainScreen].bounds.size.width
#define kScreenHeight   [UIScreen mainScreen].bounds.size.height

#define PHOTO_HEIGHT  80

@interface MineController ()

@end


@implementation MineController

//-(void)viewWillAppear:(BOOL)animated{
//    [super viewWillAppear:YES];
//    self.animationType = AnimationCherryType;//开启动画
//    [self prefersStatusBarHidden];
//}

-(void)viewDidLoad{

    [super viewDidLoad];
    
    [self createLoginLayer];

    
}


#pragma mark  创建登录头像图层
-(void) createLoginLayer{

    //自定义图层
    CALayer *layer=[[CALayer alloc]init];
    layer.bounds=CGRectMake(0, 0, PHOTO_HEIGHT, PHOTO_HEIGHT);
    layer.position=CGPointMake(kScreenWidth/2,_logInImg.height/2+20 );
    layer.backgroundColor=[UIColor redColor].CGColor;
    layer.cornerRadius=PHOTO_HEIGHT/2;

    layer.anchorPoint = CGPointMake(0.5, 0.5);
    //注意仅仅设置圆角，对于图形而言可以正常显示，但是对于图层中绘制的图片无法正确显示
    //如果想要正确显示则必须设置masksToBounds=YES，剪切子图层
    layer.masksToBounds=YES;
    //阴影效果无法和masksToBounds同时使用，因为masksToBounds的目的就是剪切外边框，
    //而阴影效果刚好在外边框
    //    layer.shadowColor=[UIColor grayColor].CGColor;
    //    layer.shadowOffset=CGSizeMake(2, 2);
    //    layer.shadowOpacity=1;
    //设置边框
    layer.borderColor=[UIColor yellowColor].CGColor;
    layer.borderWidth=5;

    //设置图层代理
    layer.delegate=self;

    //添加图层到根图层
    [self.logInImg.layer addSublayer:layer];

    //调用图层setNeedDisplay,否则代理方法不会被调用
    [layer setNeedsDisplay];



}
-(void) drawLayer:(CALayer *)layer inContext:(CGContextRef)ctx{

    //    NSLog(@"%@",layer);//这个图层正是上面定义的图层
    CGContextSaveGState(ctx);

    //图形上下文形变，解决图片倒立的问题
    CGContextScaleCTM(ctx, 1, -1);
    CGContextTranslateCTM(ctx, 0, -PHOTO_HEIGHT);

    UIImage *image=[UIImage imageNamed:@"Head_portrait"];
    //注意这个位置是相对于图层而言的不是屏幕
    CGContextDrawImage(ctx, CGRectMake(0, 0, PHOTO_HEIGHT, PHOTO_HEIGHT), image.CGImage);

    //    CGContextFillRect(ctx, CGRectMake(0, 0, 100, 100));
    //    CGContextDrawPath(ctx, kCGPathFillStroke);

    CGContextRestoreGState(ctx);

}

@end
