//
//  MineController.h
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseViewController.h"
#import "UIViewExt.h"

@interface MineController : UITableViewController
@property (weak, nonatomic) IBOutlet UIImageView *logInImg;
@property (weak, nonatomic) IBOutlet UILabel *logInLabel;


@end
