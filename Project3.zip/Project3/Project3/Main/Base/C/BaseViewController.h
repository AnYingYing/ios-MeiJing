//
//  BaseViewController.h
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kWidth self.view.bounds.size.width
#define kHeight self.view.bounds.size.height
#define kArcColor [UIColor colorWithRed:arc4random()%256/255.0 green:arc4random()%256/255.0 blue:arc4random()%256/255.0 alpha:1]
typedef NS_ENUM(NSUInteger,AnimationType) {
    AnimationNone,
    AnimationFireType, //烟花
    AnimationCherryType, //樱花
    AnimationSnowType, //雪花
};
@interface BaseViewController : UIViewController<UISearchBarDelegate>
@property (nonatomic) AnimationType animationType;

@property(nonatomic,strong) UIButton *soSuoBtn;



@end
