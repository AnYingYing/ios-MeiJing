//
//  LeadViewController.m
//  WXMovie
//
//  Created by mac1 on 16/7/29.
//  Copyright © 2016年 bing. All rights reserved.
//

#import "LeadViewController.h"

#import "BaseTabBarController.h"

@interface LeadViewController () <UIScrollViewDelegate>{
    
    UIScrollView *_scrollView;
    
    NSArray *imageArray;
    NSArray *pointImgArray;
    
    NSInteger pageNum;
    
    UIImageView *leftImgView;
    UIImageView *centerImgView;
    UIImageView *rightImgView;
    
}

@end

@implementation LeadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    pageNum = 0;
    
    [self loadArray];
    
    _scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    
    _scrollView.backgroundColor = [UIColor yellowColor];
    
    _scrollView.userInteractionEnabled = YES;
    
    _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width*imageArray.count, _scrollView.frame.size.height);
    
    _scrollView.pagingEnabled = YES;
    
    _scrollView.delegate = self;
    
    
    
    [self.view addSubview:_scrollView];
    
    [self loadImg];
}

- (void) loadArray {
    
    imageArray = [NSArray array];
    pointImgArray = [NSArray array];
    
    imageArray = @[@"LaunchImage",@"LaunchImage",@"LaunchImage",@"LaunchImage",@"LaunchImage"];
    
    pointImgArray = @[@"guideProgress1@2x",@"guideProgress2@2x",@"guideProgress3@2x",@"guideProgress4@2x",@"guideProgress5@2x"];
}

- (void) loadImg {
    
    leftImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, _scrollView.frame.size.width, _scrollView.frame.size.height)];
    leftImgView.image = [UIImage imageNamed:imageArray[(pageNum+imageArray.count-1)%imageArray.count]];
    [_scrollView addSubview:leftImgView];
    
    
    centerImgView = [[UIImageView alloc] initWithFrame:CGRectMake(_scrollView.frame.size.width, 0, _scrollView.frame.size.width, _scrollView.frame.size.height)];
    centerImgView.image = [UIImage imageNamed:imageArray[pageNum%imageArray.count]];
    [_scrollView addSubview:centerImgView];
    
    
    rightImgView = [[UIImageView alloc] initWithFrame:CGRectMake(_scrollView.frame.size.width*2, 0, _scrollView.frame.size.width, _scrollView.frame.size.height)];
    rightImgView.image = [UIImage imageNamed:imageArray[(pageNum+1)%imageArray.count]];
    [_scrollView addSubview:rightImgView];
    
    
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    if (scrollView.contentOffset.x > 20) {
        
        
        pageNum ++;
        
        _scrollView.contentOffset = CGPointMake(_scrollView.frame.size.width,0);
        
        if (pageNum > imageArray.count-1) {
            //pageNum = 0;
            BaseTabBarController *baseTabBar = [[BaseTabBarController alloc] init];
            
            self.view.window.rootViewController = baseTabBar;
            
            
        }
    } else if(scrollView.contentOffset.x < _scrollView.frame.size.width/2) {
        //pageNum --;
        
        if (pageNum < 0) {
            //pageNum = imageArray.count -1;
        }
    }
    
    [self loadImg];
    
    
}


@end
