//
//  BaseNavigationController.m
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseNavigationController.h"


@interface BaseNavigationController ()

@end

@implementation BaseNavigationController

-(void) viewDidLoad{

    //barTintColor
    self.navigationBar.barTintColor = [UIColor colorWithRed:42.0/255 green:169.0/255 blue:151.0/255 alpha:1];
}

@end
