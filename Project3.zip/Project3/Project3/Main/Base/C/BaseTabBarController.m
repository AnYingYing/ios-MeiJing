//
//  BaseTabBarController.m
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseTabBarController.h"
//定义宽度和高度
#define kScreenWidth    [UIScreen mainScreen].bounds.size.width
#define kScreenHeight   [UIScreen mainScreen].bounds.size.height

@interface BaseTabBarController (){
    NSArray *arr;
    NSUInteger *select;
}

@end
@implementation BaseTabBarController

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    [self removeSystemTabBar];


}

//移除系统tabBar
-(void) removeSystemTabBar{

    for (UIView *view in self.tabBar.subviews) {

        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {

            [view removeFromSuperview];
        }
    }

}
-(void)viewDidLoad{

    [super viewDidLoad];

    [self loadStoryBoard];

    [self createTabBarV];

    
}

#pragma  mark 加载故事版
-(void) loadStoryBoard{
    //1. 加载故事版
    UIStoryboard *homeStroy = [UIStoryboard  storyboardWithName:@"Home" bundle:nil] ;
    UIStoryboard *DiscoverStroy = [UIStoryboard  storyboardWithName:@"Discover" bundle:nil] ;
    UIStoryboard *MineStroy = [UIStoryboard  storyboardWithName:@"Mine" bundle:nil] ;

    //2 添加到有个数组
    NSArray * viewStroys = @[[homeStroy instantiateInitialViewController],
                             [DiscoverStroy instantiateInitialViewController],
                             [MineStroy instantiateInitialViewController]];


    self.viewControllers = viewStroys;
}

#pragma  mark  创建导航栏按钮
-(void) createTabBarV{

    //news_cell_more_bar@2x
//    [self.tabBar setBackgroundImage:[UIImage imageNamed:@"tabBar_Bg"]];
        UIImageView *tabBarImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth , 55)];
//
    tabBarImg.image = [UIImage imageNamed:@"tabBar_Bg"];
//
    [self.tabBar addSubview:tabBarImg];

        arr = @[@"home",@"find",@"mine"];

    float  width = kScreenWidth/3;
    for (int i = 0 ; i< arr.count; i++) {

        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        
        button.frame = CGRectMake(width*i + width/4, 3, 50, 45);

        NSString *imgName = arr[i];
        [button setImage:[UIImage imageNamed:imgName] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_n",imgName]] forState:UIControlStateSelected];

        button.tag  = 1000 +i;
        [button addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];

        [self.tabBar addSubview:button];

    }

//    self.tabBar.backgroundColor = [UIColor redColor];
}

-(void) btnAction:(UIButton *) btn{

    self.selectedIndex = btn.tag -1000;


    //循环便利所有的btn关闭selected
    for (int i = 0; i < self.viewControllers.count; i++) {

        UIButton *button = [self.tabBar viewWithTag:1000+i];

        button.selected = NO;

        }

                btn.selected = !btn.selected;

}


@end
