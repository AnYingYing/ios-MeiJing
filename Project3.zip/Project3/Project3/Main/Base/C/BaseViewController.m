//
//  BaseViewController.m
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseViewController.h"




@interface BaseViewController ()

@end
@implementation BaseViewController


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];



    if ( !self.animationType ){
        //在后台线程中执行===在子线程中执行
//        [self performSelectorInBackground:@selector(run) withObject:@"隐式创建"];

//        [self run];

    }

    //[self prefersStatusBarHidden];



}


-(void)run{

    self.animationType = AnimationCherryType;//开启动画

}




-(void) viewDidLoad{

    
}



#pragma mark AnimationType  setter
-(void)setAnimationType:(AnimationType)animationType{
    if (_animationType != animationType) {
        _animationType = animationType;
    }
    switch (animationType) {
        case 0:

            break;
        case 1:
            [self fireAnimation];
            break;
        case 2:
            [self cherryCoreAnimation];
            break;
        case 3:
            [self snowCoreAnimation];
            break;

        default:
            break;
    }
}
#pragma mark 雪花飘落动画❄️
-(void)snowCoreAnimation{
    CADisplayLink *disPlay = [CADisplayLink displayLinkWithTarget:self selector:@selector(handleAction:)];
    disPlay.frameInterval = 5;
    [disPlay addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
}
-(void)handleAction:(CADisplayLink*)disPlayLink{
    UIImage *image = [UIImage imageNamed:@"雪花"];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    CGFloat scale = arc4random_uniform(60) / 100.0;
    imageView.transform = CGAffineTransformMakeScale(scale, scale);
    CGSize winSize = self.view.bounds.size;
    CGFloat x = arc4random_uniform(winSize.width);
    CGFloat y = - imageView.frame.size.height;
    imageView.center = CGPointMake(x, y);
    [self.view addSubview:imageView];
    [UIView animateWithDuration:arc4random_uniform(15) animations:^{
        CGFloat toX = arc4random_uniform(winSize.width);
        CGFloat toY = imageView.frame.size.height * 0.5 + winSize.height;
        imageView.center = CGPointMake(toX, toY);
        imageView.transform = CGAffineTransformRotate(imageView.transform, arc4random_uniform(M_PI * 4));
        imageView.alpha = 0.5;
    } completion:^(BOOL finished) {
        [imageView removeFromSuperview];
    }];
}
#pragma mark 樱花飘落的动画🌸
-(void)cherryCoreAnimation{
    CAEmitterLayer *cherryLayer = [CAEmitterLayer layer];
    cherryLayer.emitterPosition = CGPointMake(100, -30);
    cherryLayer.emitterSize = CGSizeMake(kWidth, kHeight);
    cherryLayer.emitterMode = kCAEmitterLayerOutline;
    CAEmitterCell *cell = [CAEmitterCell emitterCell];
    cell.contents = (__bridge id)[UIImage imageNamed:@"樱花瓣2.jpg"].CGImage;
    //缩放比例
    cell.scale = 0.02;
    cell.scaleRange = 0.5;
    //每秒产生的花瓣数
    cell.birthRate = 5;
    cell.lifetime = 50;
    //每秒花瓣边透明的速度
    cell.alphaSpeed = -0.01;
    //秒速五厘米
    cell.velocity = 40;
    cell.velocityRange = 60;
    //花瓣掉落的角度范围
    cell.emissionRange = M_PI;
    //花瓣的颜色
    //cell.color = kArcColor.CGColor;
    //花瓣旋转的速度
    cell.spin = M_PI_4;
    // 阴影的 不透明 度
    cherryLayer.shadowOpacity = 0.2;
    // 阴影化开的程度（就像墨水滴在宣纸上化开那样）
    cherryLayer.shadowRadius = 8;
    //阴影的偏移量
    cherryLayer.shadowOffset = CGSizeMake(2, 2);
    //阴影的颜色
    cherryLayer.shadowColor = kArcColor.CGColor;
    cherryLayer.emitterCells = [NSArray arrayWithObjects:cell, nil];
    [self.view.layer addSublayer:cherryLayer];

}
#pragma mark 烟花喷射动画
-(void)fireAnimation{
    // Cells spawn in the bottom, moving up
    CAEmitterLayer *fireworksEmitter = [CAEmitterLayer layer];
    fireworksEmitter.emitterPosition = CGPointMake(kWidth/2, kHeight);
    fireworksEmitter.emitterSize	= CGSizeMake(1, 0.0);
    fireworksEmitter.emitterMode	= kCAEmitterLayerOutline;
    fireworksEmitter.emitterShape	= kCAEmitterLayerLine;
    fireworksEmitter.renderMode		= kCAEmitterLayerAdditive;
    //fireworksEmitter.seed = 500;//(arc4random()%100)+300;

    // Create the rocket
    CAEmitterCell* rocket = [CAEmitterCell emitterCell];
    rocket.birthRate		= 6.0;
    rocket.emissionRange	= 0.12 * M_PI;  // some variation in angle
    rocket.velocity			= 500;
    rocket.velocityRange	= 150;
    rocket.yAcceleration	= 0;
    rocket.lifetime			= 2.02;	// we cannot set the birthrate < 1.0 for the burst
    rocket.contents			= (id) [[UIImage imageNamed:@"ball"] CGImage];
    rocket.scale			= 0.2;
    //    rocket.color			= [[UIColor colorWithRed:1 green:0 blue:0 alpha:1] CGColor];
    rocket.greenRange		= 1.0;		// different colors
    rocket.redRange			= 1.0;
    rocket.blueRange		= 1.0;
    rocket.spinRange		= M_PI;		// slow spin

    // the burst object cannot be seen, but will spawn the sparks
    // we change the color here, since the sparks inherit its value
    CAEmitterCell* burst = [CAEmitterCell emitterCell];
    burst.birthRate			= 1.0;		// at the end of travel
    burst.velocity			= 0;
    burst.scale				= 2.5;
    burst.redSpeed			=-1.5;		// shifting
    burst.blueSpeed			=+1.5;		// shifting
    burst.greenSpeed		=+1.0;		// shifting
    burst.lifetime			= 0.35;

    // and finally, the sparks
    CAEmitterCell* spark = [CAEmitterCell emitterCell];
    spark.birthRate			= 666;
    spark.velocity			= 125;
    spark.emissionRange		= 2* M_PI;	// 360 deg
    spark.yAcceleration		= 75;		// gravity
    spark.lifetime			= 3;
    spark.contents			= (id) [[UIImage imageNamed:@"fire"] CGImage];
    spark.scale		        =0.5;
    spark.scaleSpeed		=-0.2;
    spark.greenSpeed		=-0.1;
    spark.redSpeed			= 0.4;
    spark.blueSpeed			=-0.1;
    spark.alphaSpeed		=-0.5;
    spark.spin				= 2* M_PI;
    spark.spinRange			= 2* M_PI;

    // putting it together
    fireworksEmitter.emitterCells	= [NSArray arrayWithObject:rocket];
    rocket.emitterCells				= [NSArray arrayWithObject:burst];
    burst.emitterCells				= [NSArray arrayWithObject:spark];
    [self.view.layer addSublayer:fireworksEmitter];
}


@end
