//
//  LeadViewController.h
//  WXMovie
//
//  Created by mac1 on 16/7/29.
//  Copyright © 2016年 bing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeadViewController : UIViewController

@end
