//
//  HTUrlDic.m
//  Project3
//
//  Created by mac1 on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "HTUrlDic.h"

@implementation HTUrlDic

+ (NSMutableArray *) getParamArrWithUrlStrArr:(NSMutableArray *) urlStrArr {
    

        //用来作为函数的返回值，数组里里面可以存放每个url转换的字典
        NSMutableArray
        *arrayData = [NSMutableArray arrayWithCapacity:4];
        
        //获取数组，数组里装得是url
        NSMutableArray *arrayURL = urlStrArr;
        
        //循环对数组中的每个url进行处理，把参数转换为字典
        for (int i= 0; i < arrayURL.count; i ++)
        {
            //获取问号的位置，问号后是参数列表
            NSRange
            range = [arrayURL[i] rangeOfString:@"?"];

            
            //获取参数列表
            NSString
            *propertys = [arrayURL[i] substringFromIndex:(int)(range.location+1)];

            
            //进行字符串的拆分，通过&来拆分，把每个参数分开
            NSArray
            *subArray = [propertys componentsSeparatedByString:@"&"];

            
            //把subArray转换为字典
            //tempDic中存放一个URL中转换的键值对
            NSMutableDictionary
            *tempDic = [NSMutableDictionary dictionaryWithCapacity:4];
            
            for (int j
                 = 0 ; j < subArray.count; j++)
            {
                //在通过=拆分键和值
                NSArray
                *dicArray = [subArray[j] componentsSeparatedByString:@"="];

                //给字典加入元素
                [tempDic
                 setObject:dicArray[1] forKey:dicArray[0]];
            }

            [arrayData
             addObject:tempDic];
        }
        
        return arrayData;
    
    
}


@end
