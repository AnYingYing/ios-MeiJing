//
//  UIView+HTUIView_EXT.h
//  Project3
//
//  Created by mac1 on 16/9/9.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (HTUIView_EXT)

@property (nonatomic,assign) CGFloat top;

@property (nonatomic,assign) CGFloat botton;

@property (nonatomic,assign) CGFloat left;

@property (nonatomic,assign) CGFloat right;


@end
