//
//  UIView+HTUIView_EXT.m
//  Project3
//
//  Created by mac1 on 16/9/9.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "UIView+HTUIView_EXT.h"

@implementation UIView (HTUIView_EXT)

- (CGFloat)top {
    
    return self.frame.origin.y;
}

- (void)setTop:(CGFloat)top {
    
    CGRect newFrame = self.frame;
    
    newFrame.origin.y = top;
    
    self.frame = newFrame;
}

- (CGFloat)botton {
    
    return self.frame.origin.y + self.frame.size.height;
    
}

- (void)setBotton:(CGFloat)botton {
    
    CGRect newFrame = self.frame;
    
    newFrame.origin.y = botton - self.frame.size.height;
    
    self.frame = newFrame;
    
}

- (CGFloat)left {
    
    return self.frame.origin.x;
    
}

- (void)setLeft:(CGFloat)left {
    
    CGRect newFrame= self.frame;
    
    newFrame.origin.x = left;
    
    self.frame = newFrame;
    
}

- (CGFloat)right {
    
    return self.frame.origin.x + self.frame.size.width;
    
}

- (void)setRight:(CGFloat)right {
    
    CGRect newFrame = self.frame;
    
    newFrame.origin.x = right - newFrame.size.width;
    
    self.frame = newFrame;
    
}


@end
