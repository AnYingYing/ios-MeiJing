//
//  DiscoverModel.h
//  Project3
//
//  Created by mac on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONModel.h"

/*
 {
 "status": "success",
 "channels": [
 

 {
 "id": "u8040",
 "bookcount": "202.5万人订阅",
 "rate": 5,
 "top_words": [
 "国内",
 "国内游",
 "境内"
 ],
 "name": "国内游",
 "qid": 809,
 "score": 0,
 "image": "http://s.go2yd.com/b/icrex6gr_e90ud1d1.jpg",
 "type": "topic"
 },
 

 {
 "id": "u196",
 "bookcount": "66.3万人订阅",
 "rate": 5,
 "top_words": [
 "古城",
 "凤凰古城",
 "大理古城"
 ],
 "name": "古城",
 "qid": 14,
 "score": 0,
 "image": "http://s.go2yd.com/b/icrezsva_bf00d1d1.jpg",
 "type": "topic"
 },
 {
 "id": "u10351",
 "bookcount": "52.6万人订阅",
 "rate": 5,
 "top_words": [
 "古镇",
 "西塘古镇",
 "上里古镇"
 ],
 "name": "古镇",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/idf8x87f_eq0ud1d1.jpg",
 "type": "topic"
 },
 {
 "id": "u1273",
 "bookcount": "38.8万人订阅",
 "rate": 5,
 "top_words": [
 "凤凰古城",
 "湖南凤凰",
 "湘西凤凰"
 ],
 "name": "凤凰古城",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/ilhpqv2t_0f0gd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "u11469",
 "bookcount": "32.1万人订阅",
 "rate": 5,
 "top_words": [
 "镇远古镇",
 "镇远古城",
 "镇远县"
 ],
 "name": "镇远古镇",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/im7fzn9b_2e0fd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "e361845",
 "bookcount": "34.3万人订阅",
 "rate": 5,
 "top_words": [
 "乌镇",
 "茅盾故居"
 ],
 "name": "乌镇旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icwqd7by_bh0bd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "e134503",
 "bookcount": "32.8万人订阅",
 "rate": 5,
 "top_words": [
 "西塘古镇",
 "西塘镇",
 "西塘"
 ],
 "name": "西塘旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/id9x6f3p_870ud1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9233",
 "bookcount": "39万人订阅",
 "rate": 5,
 "top_words": [
 "798艺术区",
 "八大处",
 "北海公园"
 ],
 "name": "北京旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvq54rf_7d09d1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9207",
 "bookcount": "33.9万人订阅",
 "rate": 5,
 "top_words": [
 "香港",
 "香港旅游",
 "香港岛"
 ],
 "name": "香港旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvjigj3_540od1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9208",
 "bookcount": "31.9万人订阅",
 "rate": 5,
 "top_words": [
 "澳门",
 "大三巴牌坊",
 "妈祖阁"
 ],
 "name": "澳门旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvjk9bs_9i0sd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9209",
 "bookcount": "30.9万人订阅",
 "rate": 5,
 "top_words": [
 "海南",
 "海南省",
 "三亚"
 ],
 "name": "海南旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/ich1y3s8_2k00d1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9210",
 "bookcount": "16万人订阅",
 "rate": 5,
 "top_words": [
 "广东",
 "广东省",
 "广州"
 ],
 "name": "广东旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icldflby_750ud1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9211",
 "bookcount": "7万人订阅",
 "rate": 5,
 "top_words": [
 "广西",
 "广西壮族自治区",
 "南宁"
 ],
 "name": "广西旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/in05zet1_7b0id1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9212",
 "bookcount": "11.9万人订阅",
 "rate": 5,
 "top_words": [
 "云南",
 "云南省",
 "丽江"
 ],
 "name": "云南旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvld3ew_7s0ud1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9219",
 "bookcount": "9.9万人订阅",
 "rate": 5,
 "top_words": [
 "江苏",
 "江苏省",
 "南京"
 ],
 "name": "江苏旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvokt09_380ud1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9218",
 "bookcount": "8万人订阅",
 "rate": 5,
 "top_words": [
 "上海",
 "魔都",
 "上海市"
 ],
 "name": "上海旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvq7iwb_910gd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "u8244",
 "bookcount": "10.8万人订阅",
 "rate": 5,
 "top_words": [
 "西藏",
 "西藏自治区",
 "拉萨"
 ],
 "name": "西藏旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvlmy96_5s07d1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9239",
 "bookcount": "9.8万人订阅",
 "rate": 5,
 "top_words": [
 "台湾",
 "台湾省",
 "台北"
 ],
 "name": "台湾旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvjd03m_9300d1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9222",
 "bookcount": "6.3万人订阅",
 "rate": 5,
 "top_words": [
 "河南",
 "河南省",
 "郑州"
 ],
 "name": "河南旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvoszce_0u0ud1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9217",
 "bookcount": "9.6万人订阅",
 "rate": 5,
 "top_words": [
 "杭州",
 "绍兴",
 "会稽山"
 ],
 "name": "浙江旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvonuu6_0009d1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9220",
 "bookcount": "6.4万人订阅",
 "rate": 5,
 "top_words": [
 "查济古建筑群",
 "黄山",
 "绩溪龙川"
 ],
 "name": "安徽旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/in05hbti_a009d1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9225",
 "bookcount": "11.8万人订阅",
 "rate": 5,
 "top_words": [
 "四川",
 "四川省",
 "成都"
 ],
 "name": "四川旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/ik7tfk7f_7d0fd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9227",
 "bookcount": "4.9万人订阅",
 "rate": 5,
 "top_words": [
 "青海",
 "青海省",
 "青海湖"
 ],
 "name": "青海旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/iclopmqn_cf0qd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9221",
 "bookcount": "8.3万人订阅",
 "rate": 5,
 "top_words": [
 "济南",
 "青岛",
 "威海"
 ],
 "name": "山东旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvqi005_3r0bd1d1.jpg",
 "type": "topic"
 },
 {
 "id": "t9230",
 "bookcount": "7.3万人订阅",
 "rate": 5,
 "top_words": [
 "陕西",
 "陕西省",
 "西安"
 ],
 "name": "陕西旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvlxl3l_4f0id1d1.jpg",
 "type": "topic"
 },
 

 {
 "id": "t9231",
 "bookcount": "6.5万人订阅",
 "rate": 5,
 "top_words": [
 "山西",
 "山西省",
 "太原"
 ],
 "name": "山西旅游",
 "qid": 0,
 "score": 0,
 "image": "http://s.go2yd.com/b/icvrwc11_0g0od1d1.jpg",
 "type": "topic"
 }
 ],
 "code": 0
 }
 */
@interface DiscoverModel : JSONModel
@property(nonatomic,copy) NSString *id;
@property(nonatomic,copy) NSString *bookcount;

@property(nonatomic,assign) NSInteger rate;
@property(nonatomic,strong) NSArray *top_words;
@property(nonatomic,copy) NSString *name;

@property(nonatomic,assign) NSInteger qid;

@property(nonatomic,assign) NSInteger score;

@property(nonatomic,copy) NSString *image;
@property(nonatomic,copy) NSString *type;




@end
