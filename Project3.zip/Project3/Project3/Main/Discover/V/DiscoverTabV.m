//
//  DiscoverTabV.m
//  Project3
//
//  Created by mac on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "DiscoverTabV.h"
#import "DiscoverTableViewCell.h"

#import "DiscoverModel.h"

#import "DataSource.h"

#import "UIViewExt.h"

static NSString  * CellIndex =@"cell_1";
@interface DiscoverTabV ()

@end

@implementation DiscoverTabV

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {


        [self createTabV];


    }
    return self;
}


-(void) createTabV{

    NSLog(@"%ld",self.dataArr.count);

    self.dataSource = self;
    self.delegate =self;

    //添加头视图
    [self createHeaderV];
    //注册单元格
    [self  registerNib:[UINib nibWithNibName:@"DiscoverTableViewCell" bundle:nil]
             forCellReuseIdentifier:CellIndex];



}

//添加头视图
-(void) createHeaderV{

    self.headV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 60)];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, _headV.height/2-15, 100, 30)];
//    label.center = CGPointMake(60, _headV.height/2);

    label.text = @"频道广场";

    [_headV addSubview:label];

    self.tableHeaderView = self.headV;

}

#pragma mark - UITableViewDataSource
//单元格个数
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{


    return self.dataArr.count;
}
//单元格内容
-(UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    DiscoverTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIndex forIndexPath:indexPath];
//    DiscoverModel *model = [[DiscoverModel alloc] init];
    cell.model = self.dataArr[indexPath.row];

    return cell;
    
    
    
}


-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return  80;
}


@end
