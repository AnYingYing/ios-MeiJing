//
//  DiscoverTableViewCell.m
//  Project3
//
//  Created by mac on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "DiscoverTableViewCell.h"

#import "UIViewExt.h"

@implementation DiscoverTableViewCell

- (void)awakeFromNib {

    _subscribeLabel.layer.cornerRadius = _subscribeLabel.height/2;
    _subscribeLabel.layer.borderWidth =0.5;

    //0 238 238
    [_subscribeLabel setTitleColor:[UIColor colorWithRed:0/255.0 green:238/255.0 blue:238/255.0 alpha:1]forState:UIControlStateNormal ];
    [_subscribeLabel setTitleColor:[UIColor blackColor]forState:UIControlStateSelected];

    _subscribeLabel.layer.borderColor=[UIColor colorWithRed:0/255.0 green:238/255.0 blue:238/255.0 alpha:1].CGColor;




}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];


}

-(void) setModel:(DiscoverModel *)model{

    _model = model;

    [self layoutIfNeeded];

}

-(void) layoutSubviews{

    _nameLable.text = _model.name;

    _bookcountLabel.text =_model.bookcount;

    
}
@end
