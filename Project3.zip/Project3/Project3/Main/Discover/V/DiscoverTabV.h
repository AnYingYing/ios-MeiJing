//
//  DiscoverTabV.h
//  Project3
//
//  Created by mac on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

//定义宽度和高度
#define kScreenWidth    [UIScreen mainScreen].bounds.size.width
#define kScreenHeight   [UIScreen mainScreen].bounds.size.height
@interface DiscoverTabV : UITableView<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) NSArray *dataArr;

@property(nonatomic,strong) UIView *headV;

@end
