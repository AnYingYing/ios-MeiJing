//
//  DiscoverTableViewCell.h
//  Project3
//
//  Created by mac on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DiscoverModel.h"
@interface DiscoverTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLable;
@property (weak, nonatomic) IBOutlet UILabel *bookcountLabel;

@property (weak, nonatomic) IBOutlet UIButton *subscribeLabel;


@property(nonatomic,strong) DiscoverModel *model;
@end


