//
//  DiscoverController.m
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "DiscoverController.h"

#import "AFNetworking.h"

#import "DiscoverModel.h"

#import "UIViewExt.h"

#import "SearchController.h"
#import "WebController.h"

#import "DiscoverTableViewCell.h"

#import "HTDataService.h"


#define KScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define KScreenHeight ([UIScreen mainScreen].bounds.size.height)

@interface DiscoverController ()

//请求头
@property (nonatomic, strong) NSDictionary *requestHeadDic;

@property (nonatomic, strong) WebController *webC;

@end

static NSString  * CellIndex =@"cell_1";

@implementation DiscoverController


-(void)viewDidLoad{

    [super viewDidLoad];

    //NSLog(@"888888888888888888");

    [self loadData];

    [self createSearch];
    
    [self createDiscoverTabView];
    
    
    
   }


-(void) loadData{

    /*
     //http://a1.go2yd.com/Website/appx/channel-exploration

     http://a1.go2yd.com/Website/appx/channel-exploration?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi

     http://a1.go2yd.com/Website/appx/channel-exploration?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi
     GET /Website/appx/channel-exploration?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi HTTP/1.1
     */

//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];


    NSString *urlStr = @"http://a1.go2yd.com/Website/appx/channel-exploration";


    //?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi
    //请求头
    NSDictionary *dic1 = @{ @"Accept-Encoding": @"gzip, deflate",
                            @"Cookie" : @"JSESSIONID=98YR05_8fY2ezCQCju_y_w"
                            //JSESSIONID=98YR05_8fY2ezCQCju_y_w

                           };


    /*platform=1
     & appid=meijing
     & cv=3.1.8
     & version=010911
     &  net=wifi

    */

    //请求参数
    NSDictionary *dic2 = @{
                          @"platform":@1,
                          @"appid":@"meijing",
                          @"cv":@"3.1.8",
                          @"version":@"010911",
                          @"net":@"wifi"

                          };

    
    self.dataArr = [[NSMutableArray alloc] init];
    
    [DataSource requestURL:urlStr requestHeadDic:[dic1 mutableCopy] method:@"GET" params:[dic2 mutableCopy] fileData:nil success:^(id responseResult) {

//        NSLog(@"---------%@",responseResult);
        NSArray *data = responseResult[@"channels"];

        for (NSDictionary *dic in data) {

            DiscoverModel *model = [[DiscoverModel alloc] init];
            model.name = [dic  objectForKey:@"name"];
            model.bookcount = [dic objectForKey:@"bookcount"];

            [_dataArr addObject:model];

        }
            //self.disvoverTabV.dataArr=dataArr;
        
        NSLog(@"%@",_dataArr[0]);

        [self.disvoverTabV reloadData];


    } faile:^(NSError *error) {

        NSLog(@"--------%@",error);

    }];

    

}


- (void) createSearch {
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, KScreenWidth-20, 44-10)];
    self.navigationItem.titleView = view;
    
    UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, 70, 44-10)];
    lab.text = @"美景中国";
    [view addSubview:lab];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.contentMode = UIViewContentModeScaleToFill;
    
    button.frame = CGRectMake(lab.right, 0, KScreenWidth-lab.frame.size.width-20, 44-10);
    
    [button setImage:[UIImage imageNamed:@"search_bg@2x"] forState:UIControlStateNormal];
    
    
    [button addTarget:self action:@selector(searchAction) forControlEvents:UIControlEventTouchUpInside];
    
    [view addSubview:button];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 0, button.frame.size.width, button.frame.size.height)];
    label.text = @"搜索你感兴趣的";
    [button addSubview:label];
    
}




- (void) searchAction {
    
    SearchController *search = [[SearchController alloc] init];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:search];
    
    [self presentViewController:nav animated:YES completion:nil];
    
    search.updateBlock = ^(NSString *channelName,ContentTableViewController *ctrl) {
        
        //[self.currentChannelsArray insertObject:channelName atIndex:0];
        [self.homeC.currentChannelsArray addObject:channelName];
        //[self.remainChannelsArray removeObjectAtIndex:indexPath.row];
        [self.homeC updateCurrentChannelsArrayToDefaults];
        //新增自控制器
        //[self.viewCtrls insertObject:ctrl atIndex:0];
        [self.homeC.viewCtrls addObject:ctrl];
        //新增新闻频道
        //[self.yfScrollView addTagTitle:channelName contentItem:ctrl atIndex:0];
        [self.homeC.yfScrollView addTagTitle:channelName contentItem:ctrl];
        
        [ctrl load];
        [self.homeC.collectionView reloadData];
    };
}

- (void) createDiscoverTabView {
    
    
    
    NSLog(@"%ld",self.dataArr.count);
    
    _disvoverTabV = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight) style:UITableViewStylePlain];
    
    _disvoverTabV.dataSource = self;
    _disvoverTabV.delegate =self;
    
    //添加头视图
    [self createHeaderV];
    //注册单元格
    [_disvoverTabV  registerNib:[UINib nibWithNibName:@"DiscoverTableViewCell" bundle:nil]
    forCellReuseIdentifier:CellIndex];
    
    
    [self.view addSubview:_disvoverTabV];
    
}


//添加头视图
-(void) createHeaderV{
    
    self.headV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kWidth, 60)];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, _headV.height/2-15, 100, 30)];
    //    label.center = CGPointMake(60, _headV.height/2);
    
    label.text = @"频道广场";
    
    [_headV addSubview:label];
    
    _disvoverTabV.tableHeaderView = self.headV;
    
}

#pragma mark - UITableViewDataSource
//单元格个数
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    
    return self.dataArr.count;
}
//单元格内容
-(UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DiscoverTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIndex forIndexPath:indexPath];
    //    DiscoverModel *model = [[DiscoverModel alloc] init];
    cell.model = self.dataArr[indexPath.row];
    
    return cell;
    
    
}

//单元格的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *urlStr1 = @"http://a1.go2yd.com/Website/channel/news-list-for-channel?ranker=search&dc=0&platform=1&infinite=true&cstart=0&cend=50&appid=meijing&cv=3.1.8&refresh=1&channel_id=";
    
    
    
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryForKey:@"channelsUrlDictionary"];
    
    NSLog(@"liebiao11:%@",dict);
    
    
    
    DiscoverModel *model = self.dataArr[indexPath.row];
    
    NSString *urlStr2 = dict[model.name];
    
    NSLog(@"liebiao22:%@",urlStr2);
    
    NSString *urlStr3 = @"&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&version=010911&net=wifi";
    
    NSMutableString *fullStr = [NSMutableString stringWithFormat:@"%@%@%@",urlStr1,urlStr2,urlStr3];
    
    
    [HTDataService getWithURL:fullStr params:nil headerField:[self.requestHeadDic mutableCopy] comPletionBlock:^(id data) {
        
        /*
         因为要使用WebController中的updateBlock，为了确保使用的WebController
         是同一个，所以此处不需要_webC = [[WebController alloc] init]，否则野指针
         
         Block野指针错误原因：1. Block没有实现，或者Block实现失败
         2. 使用Block的对象（同名同类，不同地址）不是同一个
         */
        _webC = [[WebController alloc] init];
        _webC.channelDataDic = data;
        
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:_webC];
        
        //创建左上角返回barButtonItem
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        
        button.frame = CGRectMake(0, 0, 45, 45);
        
        [button setTitle:@"返回" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        [button addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        
        
        _webC.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
        
        [self presentViewController:nav animated:YES completion:nil];
    
        
    }];

    
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return  80;
}

- (void) backAction {
    //关闭模态视图
    [self dismissViewControllerAnimated:YES completion:nil];
}


-(NSDictionary *)requestHeadDic {
    if (!_requestHeadDic) {
        _requestHeadDic = @{
                            @"Accept-Encoding":@"gzip, deflate",
                            @"Cookie":@"JSESSIONID=yR-ln5cCJaGn2Va63UK55A"
                            };
        //JSESSIONID=yR-ln5cCJaGn2Va63UK55A
    }
    return _requestHeadDic;
}


@end
