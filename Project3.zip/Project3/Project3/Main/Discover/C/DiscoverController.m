//
//  DiscoverController.m
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "DiscoverController.h"

#import "AFNetworking.h"

#import "DiscoverModel.h"
#import "DiscoverTabV.h"

#import "UIViewExt.h"

#import "SearchController.h"
#import "WebController.h"

#define KScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define KScreenHeight ([UIScreen mainScreen].bounds.size.height)

@interface DiscoverController ()


@end

@implementation DiscoverController


-(void)viewDidLoad{

    [super viewDidLoad];

    

    [self loadData];

    [self createSearch];
    
   }


-(void) loadData{

    /*

     http://a1.go2yd.com/Website/appx/channel-exploration?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi

     http://a1.go2yd.com/Website/appx/channel-exploration?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi
     GET /Website/appx/channel-exploration?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi HTTP/1.1
     */

//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];


    NSString *urlStr = @"http://a1.go2yd.com/Website/appx/channel-exploration";


    //?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi
    //请求头
    NSDictionary *dic1 = @{ @"Accept-Encoding": @"gzip, deflate",
                            @"Cookie" : @"JSESSIONID=aTv7FR_MLDf1yBtkFcM-Vg"

                           };


    /*platform=1
     & appid=meijing
     & cv=3.1.8
     & version=010911
     &  net=wifi

    */

    //请求参数
    NSDictionary *dic2 = @{
                          @"platform":@1,
                          @"appid":@"meijing",
                          @"cv":@"3.1.8",
                          @"version":@"010911",
                          @"net":@"wifi"

                          };

      NSMutableArray *dataArr = [NSMutableArray array];

    [DataSource requestURL:urlStr requestHeadDic:[dic1 mutableCopy] method:@"GET" params:[dic2 mutableCopy] fileData:nil success:^(id responseResult) {

//        NSLog(@"---------%@",responseResult);
        NSArray *data = responseResult[@"channels"];

        for (NSDictionary *dic in data) {

            DiscoverModel *model = [[DiscoverModel alloc] init];
            model.name = [dic  objectForKey:@"name"];
            model.bookcount = [dic objectForKey:@"bookcount"];

            [dataArr addObject:model];

        }
            self.disvoverTabV.dataArr=dataArr;
        
        NSLog(@"%@",self.disvoverTabV.dataArr[0]);

        [self.disvoverTabV reloadData];


    } faile:^(NSError *error) {

        NSLog(@"--------%@",error);

    }];

    

}


- (void) createSearch {
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, KScreenWidth-20, 44-10)];
    self.navigationItem.titleView = view;
    
    UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, 70, 44-10)];
    lab.text = @"美景中国";
    [view addSubview:lab];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.contentMode = UIViewContentModeScaleToFill;
    
    button.frame = CGRectMake(lab.right, 0, KScreenWidth-lab.frame.size.width-20, 44-10);
    
    [button setImage:[UIImage imageNamed:@"search_bg@2x"] forState:UIControlStateNormal];
    
    
    [button addTarget:self action:@selector(searchAction) forControlEvents:UIControlEventTouchUpInside];
    
    [view addSubview:button];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 0, button.frame.size.width, button.frame.size.height)];
    label.text = @"搜索你感兴趣的";
    [button addSubview:label];
    
}




- (void) searchAction {
    
    SearchController *search = [[SearchController alloc] init];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:search];
    
    [self presentViewController:nav animated:YES completion:nil];
    
    search.updateBlock = ^(NSString *channelName,ContentTableViewController *ctrl) {
        
        //[self.currentChannelsArray insertObject:channelName atIndex:0];
        [self.homeC.currentChannelsArray addObject:channelName];
        //[self.remainChannelsArray removeObjectAtIndex:indexPath.row];
        [self.homeC updateCurrentChannelsArrayToDefaults];
        //新增自控制器
        //[self.viewCtrls insertObject:ctrl atIndex:0];
        [self.homeC.viewCtrls addObject:ctrl];
        //新增新闻频道
        //[self.yfScrollView addTagTitle:channelName contentItem:ctrl atIndex:0];
        [self.homeC.yfScrollView addTagTitle:channelName contentItem:ctrl];
        
        [ctrl load];
        [self.homeC.collectionView reloadData];
    };
}



@end
