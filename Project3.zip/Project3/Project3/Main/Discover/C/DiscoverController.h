//
//  DiscoverController.h
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseViewController.h"
#import "DiscoverTabV.h"
#import <UIKit/UIKit.h>


#import "DiscoverTableViewCell.h"

#import "DataSource.h"

#import "HomeController.h"

@interface DiscoverController : BaseViewController
@property (weak, nonatomic) IBOutlet DiscoverTabV *disvoverTabV;

@property (nonatomic, strong) HomeController *homeC;

@end
