//
//  HomeLayout.h
//  Project3
//
//  Created by mac1 on 16/9/8.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>

#import "HomeModel.h"

/*
 
 下滑
 http://a1.go2yd.com/Website/channel/best-news?dc=0&platform=1&infinite=true&cstart=77&push_refresh=0&cend=107&appid=meijing&cv=3.1.8&refresh=1&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&version=010911&net=wifi
 
 再下滑1
 http://a1.go2yd.com/Website/channel/best-news?dc=0&platform=1&infinite=true&cstart=102&push_refresh=0&cend=132&appid=meijing&cv=3.1.8&refresh=1&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&version=010911&net=wifi
 
 再下滑2
 http://a1.go2yd.com/Website/channel/best-news?dc=0&platform=1&infinite=true&cstart=110&push_refresh=0&cend=140&appid=meijing&cv=3.1.8&refresh=1&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&version=010911&net=wifi
 
 */



@interface HomeLayout : NSObject


@property (nonatomic, strong) HomeModel *model;

@property (nonatomic, assign) CGFloat cellHeight;
@property (nonatomic,assign) CGRect textFrame;//微博内容

@property (nonatomic, assign) CGRect imgViewFrame;//微博图片

//首先创建一个存储frame的数组（存储9个空值的元素）
@property (nonatomic, strong) NSMutableArray *picViewFrameArr;

//所有的页数
@property (nonatomic, assign) NSInteger allPages;

@end
