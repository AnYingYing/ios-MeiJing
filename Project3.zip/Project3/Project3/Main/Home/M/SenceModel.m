//
//  SenceModel.m
//  Project3
//
//  Created by mac1 on 16/9/6.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "SenceModel.h"

@implementation SenceModel

@end
