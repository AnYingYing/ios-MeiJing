//
//  HomeModel.h
//  Project3
//
//  Created by mac1 on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseModel.h"

@protocol Optional

@end

@interface HomeModel : BaseModel

/*
 国内游:channel_id=4294628615
 http://a1.go2yd.com/Website/channel/news-list-for-channel?dc=0&platform=1&infinite=true&cstart=0&cend=30&appid=meijing&cv=3.1.8&refresh=1&channel_id=4294628615&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&version=010911&net=wifi
 
 南海（区分景点:channel_id）
 http://a1.go2yd.com/Website/channel/news-list-for-channel?dc=0&platform=1&infinite=true&cstart=0&cend=30&appid=meijing&cv=3.1.8&refresh=1&channel_id=4311049767&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&version=010911&net=wifi
 
http://a1.go2yd.com/Website/channel/news-list-for-channel?platform=1&cv=3.1.8&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&cend=50&dc=0&infinite=true&refresh=1&appid=meijing&channel_id=13004897306&cstart=0&version=010911&net=wifi
 JSESSIONID=98YR05_8fY2ezCQCju_y_w
 {
 "ctype": "news",
 "impid": "245918935_1473236447804_7139",
 "pageid": "CF_u8040",
 "dtype": 3,
 "title": "带着19个月大的宝贝儿子开始了我们自驾的第一站内蒙古",
 "meta": "245918935_1473236447804_7139",
 "docid": "0EMlGjWH",
 "itemid": "0EMlGjWH",
 "dislike_reasons": [
 "内蒙古",
 "旅游",
 "自驾游"
 ],
 "date": "2016-09-07 16:20:47",
 "b_political": true,
 "image_urls": [
 "0EMlGjIT4j",
 "0EMlGjtTgR",
 "0EMlGjGws5"
 ],
 "source": "携程",
 "url": "http://m.ctrip.com/html5/you/travels/eerguna2026/3137437.html",
 "image": "0EMlGjIT4j",
 "like": 8,
 "up": 753,
 "content_type": "news",
 "auth": true,
 "is_gov": false,
 "down": 345,
 "comment_count": 0
 },
 
 */

@property (nonatomic , copy) NSString <Optional>*ctype;
@property (nonatomic , copy) NSString <Optional>*impid;
@property (nonatomic , copy) NSString <Optional>*pageid;
@property (nonatomic , assign) int dtype;
@property (nonatomic , copy) NSString *title;//题目
@property (nonatomic , copy) NSString <Optional>*meta;
@property (nonatomic , copy) NSString <Optional>*docid;
@property (nonatomic , copy) NSString <Optional>*itemid;
@property (nonatomic , strong) NSArray <Optional>*dislike_reasons;
@property (nonatomic , copy) NSString <Optional>*date;//日期
@property (nonatomic , assign) BOOL b_political;
@property (nonatomic , strong) NSArray <Optional>*image_urls;//三张图片
@property (nonatomic , copy) NSString <Optional>*source;//资源
@property (nonatomic , copy) NSString <Optional>*url;//url
@property (nonatomic , copy) NSString <Optional>*image;//图片
@property (nonatomic , assign) int like;
@property (nonatomic , assign) int up;
@property (nonatomic , copy) NSString <Optional>*content_type;//类型
@property (nonatomic , assign) BOOL auth;
@property (nonatomic , assign) BOOL is_gov;
@property (nonatomic , assign) int down;
@property (nonatomic , assign) int comment_count;

@end
