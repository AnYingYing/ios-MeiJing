//
//  HomeLayout.m
//  Project3
//
//  Created by mac1 on 16/9/8.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "HomeLayout.h"
#import "WXLabel.h"


#define kcellheight 40//单元格原始高度
#define kedgwidth 10//边距
#define kcellspace 5

#define kwidth [UIScreen mainScreen].bounds.size.width
#define kheight [UIScreen mainScreen].bounds.size.height


@implementation HomeLayout

- (void)setModel:(HomeModel *)model {
    _model = model;
    
    [self createFrame];
}

- (void) createFrame {
    
    CGFloat cellheight = kcellheight + 2*kedgwidth;
    
    self.textFrame = CGRectMake(kedgwidth, kedgwidth, 0, 0);
    
    //每张图的大小
    CGFloat picSize = (kwidth -2*kedgwidth -2*kcellspace)/3;
    
    //如果有微博内容
    if (_model.title.length) {
        
        CGFloat textHeight = [WXLabel getTextHeight:18.0 width:kwidth-2*kedgwidth text:_model.title linespace:0];
        
        
        
        self.textFrame = CGRectMake(kedgwidth, kedgwidth, kwidth-picSize-3*kedgwidth, picSize-40);
    }
    
    
    
    //cellheight += self.textFrame.size.height;
    
    /*
     //图片
     CGFloat width = 0;
     CGFloat height = 0;
     CGFloat imgx = CGRectGetMinX(self.textFrame);//获得标签最小x
     CGFloat imgy = CGRectGetMaxY(self.textFrame) + kedgwidth;
     
     //如果有微博图片
     if (_model.thumbnail_pic) {
     
     width = 90;
     height = 90;
     
     self.imgViewFrame = CGRectMake(imgx, imgy, width, height);
     
     cellheight += self.imgViewFrame.size.height;
     }
     */
    
    
    
    //如果没有微博图片，那么_model.pic_urls存在，内容为空，.count为0
    if (_model.image_urls) {
        
        for (int i=0; i<_model.image_urls.count; i++) {
            
//            int row = i/3;
//            int culom = i%3;
            
            //第一张图片的位置
//            CGFloat picx = kedgwidth;
//            CGFloat picy = CGRectGetMaxY(self.textFrame)+kedgwidth;
            
            //CGRect picFrame = CGRectMake(picx + culom*(picSize+kcellspace), picy+row*(picSize+kcellspace), picSize, picSize);
            
            //图片位置
            CGRect picFrame = CGRectMake(kwidth-picSize-10, 10, picSize, picSize-40);
            
            //替换frame
            [self.picViewFrameArr replaceObjectAtIndex:i withObject:[NSValue valueWithCGRect:picFrame]];
        }
        
        //单元格的高度
        //1 图片的行数（0～3）
        //2 图片与图片之间的距离（0～2）
        //3 图片与正文之间的边距（0～1）
        
        //.count它有几张图片，.count就是几，所以我们为了和上面求行数相当-1
        //当只有一张图片时, (1-1)/3=0显然不对,所以再多加一个3
        NSInteger line = (_model.image_urls.count - 1+3)/3;
        
        // MAX 取两者之中的最大值,line范围(0~3),line-1范围(-1~2)
        // 当line-1为-1时，取最大值0，当line-1位0，都是0，依次类推
//        cellheight += line*picSize + MAX(0, line-1)*kcellspace+MIN(line, 1)*kedgwidth;
        cellheight += line*picSize;
    }
    
    
    self.cellHeight = cellheight;
    
}


- (NSMutableArray *)picViewFrameArr {
    
    if (_picViewFrameArr) {
        return _picViewFrameArr;
    }
    
    _picViewFrameArr = [NSMutableArray array];
    
    for (int i=0; i<9; i++) {
        
        [_picViewFrameArr addObject:[NSValue valueWithCGRect:CGRectZero]];
    }
    
    return _picViewFrameArr;
}





@end
