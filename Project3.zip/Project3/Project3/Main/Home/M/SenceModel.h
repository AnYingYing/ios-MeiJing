//
//  SenceModel.h
//  Project3
//
//  Created by mac1 on 16/9/6.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BaseModel.h"

@protocol Optional

@end

/*
 @"http://a1.go2yd.com/Website/user/get-info?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi"
 http://a1.go2yd.com/Website/appx/channel-exploration?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi
 
 http://a1.go2yd.com/Website/user/get-info?platform=1&appid=meijing&cv=3.1.8&version=010911&net=wifi
 
 "status": "success",
 "code": 0,
 "userid": 245918935,
 "utk": "42ew9j7d",
 "username": "HG_a09347c410306986",
 "nickname": "令狐海",
 "profile_url": "http://s.go2yd.com/a/9.jpg",
 "fontsize": "medium",
 "version": "010911",
 "appid": "meijing",
 
 
 "user_channels": [
 {
 "channel_id": "4294628615",
 "share_id": "u8040",
 "name": "国内游",
 "checksum": "国内游",
 "type": "topic",
 "image": "http://s.go2yd.com/b/icrex6gr_e90ud1d1.jpg",
 "fromId": "u8040"
 },

 */

@interface SenceModel : BaseModel

@property (nonatomic,copy) NSString *channel_id;
@property (nonatomic,copy) NSString *share_id;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *checksum;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *image;
@property (nonatomic,copy) NSString *fromId;

@end
