//
//  ChannelsSectionHeaderView.h
//  TTNews
//
//  Created by 瑞文戴尔 on 16/5/1.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChannelsSectionHeaderView : UICollectionReusableView

@property (nonatomic, weak) UILabel *titleLabel;

@property (nonatomic, weak) UIButton *clearButton;

@end
