//
//  SearchController.h
//  Project3
//
//  Created by mac1 on 16/9/10.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseViewController.h"

@class ContentTableViewController;

typedef void (^updateBlock)(NSString *channelName,ContentTableViewController *ctrl);



@interface SearchController : BaseViewController <UICollectionViewDataSource,UICollectionViewDelegate>

//自己最近搜索的景点名
@property (nonatomic, strong) NSMutableArray *ownerSearchs;
//自己最近搜索的景点id
@property (nonatomic, strong) NSMutableArray *ownerIds;

//大家都在搜索的景点名
@property (nonatomic, strong) NSMutableArray *otherSearchs;
//大家都在搜索的景点id
@property (nonatomic, strong) NSMutableArray *otherIds;

//输入文本框
@property (nonatomic, strong) UITextField *textF;

@property (nonatomic, copy) updateBlock updateBlock;

@end
