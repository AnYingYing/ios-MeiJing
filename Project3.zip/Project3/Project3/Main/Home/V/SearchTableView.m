//
//  SearchTableView.m
//  Project3
//
//  Created by mac1 on 16/9/10.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "SearchTableView.h"

@implementation SearchTableView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self createUI];
        
    }
    return self;
}

- (void) createUI {
    
    self.dataArray = [NSArray array];
    
    self.rowHeight = 100;
    self.delegate = self;
    self.dataSource = self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataArray.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellID = @"cellID";
    
    //UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
//    }
    
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    
    NSDictionary *dic = self.dataArray[indexPath.row];
    

    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, 200, 40)];
    nameLabel.text = dic[@"name"];
    [cell.contentView addSubview:nameLabel];
    
    UILabel *bookcountLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 50, 200, 40)];
    bookcountLabel.text = dic[@"bookcount"];
    [cell.contentView addSubview:bookcountLabel];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary *dic = self.dataArray[indexPath.row];
    
    NSString *Id = dic[@"id"];
    
    self.webblock(Id);
    
}


@end
