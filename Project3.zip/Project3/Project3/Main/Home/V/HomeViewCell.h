//
//  HomeViewCell.h
//  Project3
//
//  Created by mac1 on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HomeModel.h"
#import "HomeLayout.h"

#import "WXLabel.h"

@interface HomeViewCell : UITableViewCell <WXLabelDelegate>

@property (nonatomic, strong) WXLabel *titleLab;



@property (nonatomic, strong) HomeLayout *layout;


@property (nonatomic, strong) NSMutableArray *imageViewArr;


@property (weak, nonatomic) IBOutlet UILabel *sourceLabel;

@property (weak, nonatomic) IBOutlet UIImageView *messageImgView;

@property (weak, nonatomic) IBOutlet UILabel *messageNumLabel;

@property (weak, nonatomic) IBOutlet UIImageView *starImgView;

@property (weak, nonatomic) IBOutlet UILabel *starNumLabel;

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@end
