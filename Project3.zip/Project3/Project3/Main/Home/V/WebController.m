//
//  WebController.m
//  Project3
//
//  Created by mac1 on 16/9/11.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "WebController.h"

#import "HomeLayout.h"
#import "HomeModel.h"

#import "HomeViewCell.h"

#import "UIImageView+WebCache.h"

@interface WebController () <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) NSMutableArray *dataArray;

@end

@implementation WebController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadData];
    
    [self createTableView];
    
}

- (void) loadData {
    
    self.dataArray = [NSMutableArray array];
    
    NSArray *results = self.channelDataDic[@"result"];
    
    for (NSDictionary *dic in results) {
        
        HomeModel *model = [[HomeModel alloc] init];
        [model setValueForPropertyWithDic:dic];
        HomeLayout *layout = [[HomeLayout alloc] init];
        
        layout.model = model;
        
        [self.dataArray addObject:layout];
    }
    
}

- (void) createTableView {
    
    _tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStyleGrouped];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    [_tableView registerNib:[UINib nibWithNibName:@"HomeViewCell" bundle:nil] forCellReuseIdentifier:@"cellId"];
    
    [self.view addSubview:_tableView];
    
    //头视图
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 260)];
    
    NSString *imageUrl = self.channelDataDic[@"channel_image"];
    
    [imgView sd_setImageWithURL:[NSURL URLWithString:imageUrl]];
    
    _tableView.tableHeaderView = imgView;
    //名字标签
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 110, 100, 40)];
    nameLabel.text = self.channelDataDic[@"channel_name"];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    
    self.navigationItem.titleView = nameLabel;
    
    //右上角订阅按钮
    UIBarButtonItem *rightBtnItem = [[UIBarButtonItem alloc] initWithTitle:@"订阅" style:UIBarButtonItemStylePlain target:self action:@selector(rightBtnItemAction:)];
    
    NSDictionary *userDefaltdic = [[NSUserDefaults standardUserDefaults] objectForKey:@"channelsUrlDictionary"];
    
    if (userDefaltdic[self.channelDataDic[@"channel_name"]]) {
        rightBtnItem.title = @"已订阅";
        rightBtnItem.enabled = NO;
    }
    
    self.navigationItem.rightBarButtonItem = rightBtnItem;
}

- (void) rightBtnItemAction:(UIBarButtonItem *) btnItem {
    
    btnItem.title = @"已订阅";
    
    btnItem.enabled = NO;
    
    [self subscribeAndUpdate];
}

//点击订阅，更新数据和界面
- (void) subscribeAndUpdate {
    
    //获取沙盒对象
    NSUserDefaults *userDefalts = [NSUserDefaults standardUserDefaults];
    
    NSArray *results = self.channelDataDic[@"result"];
    NSDictionary *dic = results[2];
    
    NSString *channelId = dic[@"channel_id"];
    
    NSMutableDictionary *channelsUrlDic = [NSMutableDictionary dictionary];
    
    
    //获取沙盒数据
    NSDictionary *userDefaltdic = [userDefalts objectForKey:@"channelsUrlDictionary"];
    
    //向字典添加数据
    [channelsUrlDic setValue:channelId forKey:self.channelDataDic[@"channel_name"]];
    
    [channelsUrlDic addEntriesFromDictionary:userDefaltdic];
    
    //沙盒写入数据
    [userDefalts setObject:channelsUrlDic forKey:@"channelsUrlDictionary"];
    
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    ContentTableViewController *ctrl = [[ContentTableViewController alloc] init];
    
    ctrl.channelName = self.channelDataDic[@"channel_name"];
    ctrl.channelId = dic[@"channel_id"];
    
    if (channelId.length>0) {
        self.updateBlock(self.channelDataDic[@"channel_name"],ctrl);
    }
    
    
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataArray.count;
}

//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
//    
//    return 100;
//}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId" forIndexPath:indexPath];
    
    cell.layout = self.dataArray[indexPath.row];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeLayout *layout = self.dataArray[indexPath.row];
    
    return layout.cellHeight;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeLayout *layout = self.dataArray[indexPath.row];
    
    NSString *urlStr = layout.model.url;
    
    [self createWebPageWithChannelUrl:[NSURL URLWithString:urlStr]];
    
    
}

#pragma mark --创建web界面(搜索到对应界面时点击跳转)
- (void) createWebPageWithChannelUrl:(NSURL *)url {
    //创建web和相关控制器
    UIWebView *web = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [web loadRequest:request];
    
    UIViewController *webVC = [[UIViewController alloc] init];
    
    [webVC.view addSubview:web];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webVC];
    
    //创建左上角返回barButtonItem
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(0, 0, 45, 45);
    
    [button setTitle:@"返回" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    webVC.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    self.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    
    //弹出模态视图
    [self presentViewController:nav animated:YES completion:nil];
    
}

- (void) backAction {
    //关闭模态视图
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
