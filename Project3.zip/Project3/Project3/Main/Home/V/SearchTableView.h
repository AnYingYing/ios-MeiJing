//
//  SearchTableView.h
//  Project3
//
//  Created by mac1 on 16/9/10.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^WebBlock)(NSString *urlStr);

@interface SearchTableView : UITableView <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong)NSArray *dataArray;
//dataArray存储的是字典，字典需要的值如下：

//name旅游点名
//id旅游点的id
//bookcount订阅人数

@property (nonatomic, copy) WebBlock webblock;

@end
