//
//  HomeViewCell.m
//  Project3
//
//  Created by mac1 on 16/9/7.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "HomeViewCell.h"

#import "UIImageView+WebCache.h"

@implementation HomeViewCell

- (void)awakeFromNib {
    
    _titleLab = [[WXLabel alloc] init];
    _titleLab.numberOfLines = 0;
    //标签的字体大小如果不设置，默认为20，会影响布局
    _titleLab.backgroundColor = [UIColor whiteColor];
    _titleLab.font = [UIFont systemFontOfSize:18.0];
    _titleLab.wxLabelDelegate = self;
    [self.contentView addSubview:_titleLab];
    
}

- (void)setLayout:(HomeLayout *)layout {
    _layout = layout;
    
    _timeLabel.text = [self getTimeWithDate:_layout.model.date];
    
    //重新布局
    [self setNeedsLayout];

}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _titleLab.frame = _layout.textFrame;
    
    _titleLab.text = _layout.model.title;
    
    _titleLab.numberOfLines = 0;
    
    _sourceLabel.text = _layout.model.source;
    
    _messageNumLabel.text = [NSString stringWithFormat:@"%d", _layout.model.comment_count];
    
    
    
    
//    if (_layout.model.comment_count<0) {
//        _messageImgView.hidden = YES;
//        _messageNumLabel.hidden = YES;
//    }

    _starNumLabel.text = [NSString stringWithFormat:@"%d", _layout.model.like];
    
//    if (_layout.model.like<0) {
//        _starImgView.hidden = YES;
//        _starNumLabel.hidden = YES;
//    }
    
    
    
    
    for (int i=0; i<1; i++) {
        UIImageView *imgView = self.imageViewArr[i];
        imgView.frame = [_layout.picViewFrameArr[i] CGRectValue];
    }
    for (int i=0; i<1; i++) {
        
        UIImageView *imgView = self.imageViewArr[i];
        
        //[imgView sd_setImageWithURL:[NSURL URLWithString:_layout.model.image_urls[i]]];
        
//    http://i3.go2yd.com/image.php?type=webp_180x120&url=0GLXAopPFt&net=wifi
        
        
//http://i3.go2yd.com/image.php?type=webp_180x120&url=0GD3J0Kjbs&net=wifi

        //[imgView sd_setImageWithURL:[NSURL URLWithString:str111]];
        
        //[imgView sd_setImageWithURL:[NSURL URLWithString:@"http://i3.go2yd.com/image/0GNtjpEI8w?type=webp_212x142&net=wifi"]];
//        http://d.5857.com/xgmn_150416/desk_007.jpg
//        [imgView sd_setImageWithURL:[NSURL URLWithString:@"http://d.5857.com/xgmn_150416/desk_007.jpg"]];
        
        if(_layout.model.image_urls.count){
            
            [imgView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://i3.go2yd.com/image.php?type=webp_180x120&url=%@&net=wifi",_layout.model.image_urls[i]]]];
            
        }
        
        NSLog(@"%ld",_layout.model.image_urls.count);
        //当只有一张图片时
        if(_layout.model.image_urls.count==1){
            //imgView.contentMode = UIViewContentModeScaleAspectFit;
        }
    }

    
    
}

- (NSMutableArray *)imageViewArr {
    
    if (_imageViewArr) {
        return _imageViewArr;
    }
    
    _imageViewArr = [NSMutableArray array];
    
    for (int i=0; i<9; i++) {
        UIImageView *imgView = [[UIImageView alloc] init];
        
        imgView.userInteractionEnabled = YES;
        
        imgView.tag = i;
        
        [self.contentView addSubview:imgView];
        [_imageViewArr addObject:imgView];
    }
    return _imageViewArr;
}

//2016-09-08 10:36:29
- (NSString *) getTimeWithDate :(NSString *) dateText {
    
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    
    //日期格式
    formater.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    
    //设置语言标识（此处日期没有 星期，可以不用设置语言标识）
    formater.locale = [NSLocale localeWithLocaleIdentifier:@"en_US"];
    
    // 消息发布时间
    NSDate *date = [formater dateFromString:dateText];
    
    //当前日期时间
    NSDate *currentDate = [NSDate date];
    
    formater.dateFormat = @"mm";
    
    NSString *str1 = [formater stringFromDate:date];
    NSString *str2 = [formater stringFromDate:currentDate];
    
    NSInteger m1 = [str1 integerValue];
    NSInteger m2 = [str2 integerValue];
    
    //时差
    NSInteger Htime = [currentDate timeIntervalSinceDate:date];
    
    //分差
    NSInteger Mtime = labs(m1-m2);
    
    NSInteger timeHour = Htime/3600;
    
    
    
    if (timeHour<1) {
        return [NSString stringWithFormat:@"%ld分钟前",Mtime];
    } else {
       
        return [NSString stringWithFormat:@"%ld小时前",timeHour];
        
    }
    
    
}

@end
