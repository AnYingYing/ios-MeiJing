//
//  SearchController.m
//  Project3
//
//  Created by mac1 on 16/9/10.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "SearchController.h"

//collectionView的景点头视图
#import "ChannelsSectionHeaderView.h"

#import "ChannelCollectionViewCell.h"

#import "UIView+HTUIView_EXT.h"

#import "HTDataService.h"

#import "SearchTableView.h"

#import "WebController.h"

#define KScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define KScreenHeight ([UIScreen mainScreen].bounds.size.height)

static NSString * const collectionCellID = @"ChannelCollectionCell";
static NSString * const collectionViewSectionHeaderID = @"ChannelCollectionHeader";

@interface SearchController (){

    UICollectionView *_collectionView;
    SearchTableView *_searchTableView;
    
    WebController *_webC;
}

@property (nonatomic,strong) NSDictionary *requestHeadDic;

@end



@implementation SearchController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
//    _ownerSearchs = [NSMutableArray array];
//    _ownerIds = [NSMutableArray array];
//    
    _otherSearchs = [NSMutableArray array];
    _otherIds = [NSMutableArray array];
    
    [self requestData];

    [self createSearch];
    
    [self setupCollectionView];
    [self setupTableView];
    
    
    
    __weak SearchController *weakSelf = self;
    
    _searchTableView.webblock = ^(NSString *Id) {
      
        [weakSelf requestTableViewDataOfWeb:Id];
        
        
    };
    
}

#pragma mark --创建表视图
- (void) setupTableView {
    
    _searchTableView = [[SearchTableView alloc] initWithFrame:CGRectMake(0, 64, 0, 0)];
    
    
    
    [self.view addSubview:_searchTableView];
    
}

#pragma mark --创建集合视图
-(void)setupCollectionView {
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    flowLayout.headerReferenceSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 35);//头部
    _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:flowLayout];
    //self.collectionView.backgroundColor = [UIColor yellowColor];
    
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.alpha = 0.98;
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    
    [_collectionView addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveAction:)]];
    
    
    [_collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ChannelCollectionViewCell class]) bundle:nil] forCellWithReuseIdentifier:collectionCellID];
    
    [_collectionView registerClass:[ChannelsSectionHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:collectionViewSectionHeaderID];
    
    [self.view addSubview:_collectionView];
}


#pragma mark --请求大家都在搜索的数据
- (void) requestData {
    
    NSString *urlStr = @"http://a1.go2yd.com/Website/channel/recommend-channel?position=search&platform=1&appid=meijing&num=12&cv=3.1.8&channel_id=-999&version=010911&net=wifi";
    
    [HTDataService getWithURL:urlStr params:nil headerField:[self.requestHeadDic mutableCopy] comPletionBlock:^(id data) {
        
        NSArray *channels = data[@"channels"];
        
        for (NSDictionary *dic in channels) {
            NSString *channelName = dic[@"name"];
            NSString *channelId = dic[@"id"];
            
            [self.otherSearchs addObject:channelName];
            [self.otherIds addObject:channelId];
        }
        
        [_collectionView reloadData];
        
        //输入框提示语句
        _textF.placeholder = [NSString stringWithFormat:@"大家都在搜：%@",@"北京旅游"];
        
    }];
}

#pragma mark --请求当点击搜索表视图单元格时要跳转的界面的数据
- (void) requestTableViewDataOfWeb:(NSString *)channelId {
    
    NSString *urlStr1 = @"http://a1.go2yd.com/Website/channel/news-list-for-channel?ranker=search&dc=0&platform=1&infinite=true&cstart=0&cend=50&appid=meijing&cv=3.1.8&refresh=1&channel_id=";
    
    NSString *urlStr2 = channelId;
    
    NSString *urlStr3 = @"&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&version=010911&net=wifi";
    
    NSMutableString *fullStr = [NSMutableString stringWithFormat:@"%@%@%@",urlStr1,urlStr2,urlStr3];
    
    
    [HTDataService getWithURL:fullStr params:nil headerField:[self.requestHeadDic mutableCopy] comPletionBlock:^(id data) {
        
        /*
            因为要使用WebController中的updateBlock，为了确保使用的WebController
         是同一个，所以此处不需要_webC = [[WebController alloc] init]，否则野指针
         
         Block野指针错误原因：1. Block没有实现，或者Block实现失败
                            2. 使用Block的对象（同名同类，不同地址）不是同一个
         */
        _webC = [[WebController alloc] init];
        _webC.channelDataDic = data;
        
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:_webC];
        
        //创建左上角返回barButtonItem
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        
        button.frame = CGRectMake(0, 0, 45, 45);
        
        [button setTitle:@"返回" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        [button addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        
        
        _webC.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
        
        [self presentViewController:nav animated:YES completion:nil];
        
        [self createUpdateBlock];

    }];
    
}


- (void) createUpdateBlock{
    
    __weak SearchController *weakSelf = self;
    
        _webC.updateBlock = ^(NSString *channelName,ContentTableViewController *ctrl){
            
            weakSelf.updateBlock(channelName,ctrl);
    //
    //        [self.currentChannelsArray addObject:channelName];
    //        //[self.remainChannelsArray removeObjectAtIndex:indexPath.row];
    //        [self updateCurrentChannelsArrayToDefaults];
    //        //新增自控制器
    //        [self.viewCtrls addObject:ctrl];
    //        //新增新闻频道
    //        [self.yfScrollView addTagTitle:channelName contentItem:ctrl];
    //
    //        [self.collectionView reloadData];
            
            NSLog(@"block完整");
        };
    
    
}


#pragma mark --懒加载--请求头
-(NSDictionary *)requestHeadDic {
    if (!_requestHeadDic) {
        _requestHeadDic = @{
                            @"Accept-Encoding":@"gzip, deflate",
                            @"Cookie":@"JSESSIONID=yR-ln5cCJaGn2Va63UK55A"
                            };
    }
    return _requestHeadDic;
}


#pragma mark --UICollectionViewDataSource-- 返回collectionView的cell是否能被选中
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的组标题View
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    ChannelsSectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:collectionViewSectionHeaderID forIndexPath:indexPath];
    
    

    
    if (indexPath.section == 0) {
        headerView.titleLabel.text = @"最近搜索";
        [headerView.clearButton setTitle:@"清空历史" forState:UIControlStateNormal];
        
        [headerView.clearButton addTarget:self action:@selector(clearButtonAction) forControlEvents:UIControlEventTouchUpInside];
        
        headerView.clearButton.hidden = NO;
        
    }else if (indexPath.section == 1) {
        headerView.titleLabel.text = @"大家都在搜";
        headerView.clearButton.hidden = YES;
        
    }
    return headerView;
}

#pragma mark -- 清空历史 按钮的方法
- (void) clearButtonAction {
    
    NSMutableArray *paths = [NSMutableArray array];
    
    for (int i=0; i<self.ownerSearchs.count; i++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
        [paths addObject:indexPath];
    }
    
    [self.ownerSearchs removeAllObjects];
    [self.ownerIds removeAllObjects];
    [self updateOwnerSearchs];
    [self updateOwnerIds];
    
    [_collectionView deleteItemsAtIndexPaths:paths];
    [_collectionView reloadData];
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的组数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的每一组对应的cell个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return self.ownerSearchs.count;
    } else {
        return self.otherSearchs.count;
    }
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每个indexpath对应的cell
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    ChannelCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectionCellID forIndexPath:indexPath];
    
    cell.backgroundColor = [UIColor cyanColor];
    
    cell.delegate = self;
    [cell stopShake];
    cell.deleteButton.hidden = YES;
        if (indexPath.section == 0) {
            cell.channelName = self.ownerSearchs[indexPath.row];
            cell.theIndexPath = indexPath;
            
        } else {
            cell.channelName = self.otherSearchs[indexPath.row];
        }
    
    return cell;
    
}

#pragma mark --UICollectionViewDataSource-- 返回每个UICollectionViewCell发Size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat kDeviceWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat kMargin = 10;
    return CGSizeMake((kDeviceWidth - 5*kMargin)/4, 40);
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每一组的外边距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每个item之间的最小间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}

#pragma mark --UICollectionViewDataSource--collectionView每个item的点击响应事件
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        
        
        
        NSString *channelId = self.ownerIds[indexPath.row];
        //请求数据并且跳转到页面
        [self requestTableViewDataOfWeb:channelId];
        
        
    } else if(indexPath.section == 1)  {
        
        NSString *str = self.otherSearchs[indexPath.row];
        NSString *channelId = self.otherIds[indexPath.row];
        
        //请求数据并且跳转到页面
        [self requestTableViewDataOfWeb:channelId];
        
        int num=0;
        
        for (int i=0;i<self.ownerSearchs.count;i++) {
            
            NSString *key = self.ownerSearchs[i];
            
            if (![key isEqualToString:str]) {
                
                num ++;
                
                }
        }
        if (num == self.ownerSearchs.count) {
            [self.ownerSearchs addObject:str];
            [self.ownerIds addObject:channelId];
            
            [self updateOwnerSearchs];
            [self updateOwnerIds];
        }
    }
        
    [_collectionView reloadData];

}


#pragma mark --创建搜索
- (void) createSearch {
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, KScreenWidth-20, 44-10)];
    self.navigationItem.titleView = view;
    
    //
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, KScreenWidth-60, 44-10)];
    
    imgView.userInteractionEnabled = YES;
    
    imgView.image = [UIImage imageNamed:@"search_bg@2x"];
    
    [view addSubview:imgView];
    //
    UIImageView *smallImgView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 5, 25, 25)];
    
    smallImgView.image = [UIImage imageNamed:@"search_indicator@2x"];
    
    [imgView addSubview:smallImgView];
    //
    _textF = [[UITextField alloc] initWithFrame:CGRectMake(50, 0, imgView.frame.size.width, imgView.frame.size.height)];
    
    
    [_textF addTarget:self action:@selector(textFieldSearchAction:) forControlEvents:UIControlEventEditingChanged];
    
    [imgView addSubview:_textF];
    //
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(imgView.right+5, 0, 40, 40);
    
    [button setTitle:@"取消" forState:UIControlStateNormal];
    
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    
    [view addSubview:button];
}

//取消按钮
- (void) cancelAction {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

#pragma mark -- 搜索框搜索方法
- (void) textFieldSearchAction :(UITextField *) textF {
    
    
    
    NSString *text = textF.text;
    
    if (text.length==0) {
        
        [UIView animateWithDuration:0.5 animations:^{
            
            _searchTableView.frame = CGRectMake(0, 64, 0, 0);
            
        }];
        
        return;
    }
    
//    NSString *filterString = [NSString stringWithFormat:@"SELF LIKE[c] '%@*'",text];
//    
//    NSPredicate *pre = [NSPredicate predicateWithFormat:filterString];
//    
//    
//    
//    self.filterArray = [self.otherSearchs filteredArrayUsingPredicate:pre];
    
    
     [self requestDataWithTextFild:text];
    
    
    [UIView animateWithDuration:0.5 animations:^{
        
        _searchTableView.frame = CGRectMake(0, 64, KScreenWidth, KScreenHeight-64);
        
    }];
}

#pragma mark -- 根据自己输入的字符从网上请求数据
- (void) requestDataWithTextFild:(NSString *)text {
    
    NSMutableArray *dataArray = [NSMutableArray array];
    
    NSString *urlStr1 = @"http://a1.go2yd.com/Website/channel/search-channel?platform=1&appid=meijing&word=";
    //[fullUrlStr stringByAppendingString:urlStr1];
    
    NSString *urlStr2 = text;
    //[fullUrlStr stringByAppendingString:urlStr2];
    
    NSString *urlStr3 = @"&cv=3.1.8&version=010911&net=wifi";
    //[fullUrlStr stringByAppendingString:urlStr3];
    
   NSMutableString *fullUrlStr = [NSMutableString stringWithFormat:@"%@%@%@",urlStr1,urlStr2,urlStr3];
    	//@"http://a1.go2yd.com/Website/channel/search-channel?platform=1&appid=meijing&word=广&cv=3.1.8&version=010911&net=wifi"
    [HTDataService getWithURL:fullUrlStr params:nil headerField:[self.requestHeadDic mutableCopy] comPletionBlock:^(id data) {
        
        NSArray *channels = data[@"channels"];
        for (NSDictionary *dic in channels) {
            [dataArray addObject:dic];
        }
        
        _searchTableView.dataArray = dataArray;
        [_searchTableView reloadData];
    }];
    
}


#pragma mark --创建web界面(搜索到对应界面时点击跳转)
- (void) createWebPageWithChannelUrl:(NSURL *)url {
    //创建web和相关控制器
    UIWebView *web = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [web loadRequest:request];
    
    UIViewController *webVC = [[UIViewController alloc] init];
    
    [webVC.view addSubview:web];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webVC];
    
    //创建左上角返回barButtonItem
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(0, 0, 45, 45);
    
    [button setTitle:@"返回" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    webVC.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    self.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    
    //弹出模态视图
    [self presentViewController:nav animated:YES completion:nil];
    
}

- (void) backAction {
    //关闭模态视图
    [self dismissViewControllerAnimated:YES completion:nil];
}



#pragma mark -- 数据的懒加载
- (NSMutableArray *)ownerSearchs {
    
    if (_ownerSearchs) {
        return _ownerSearchs;
    }
    
    _ownerSearchs = [NSMutableArray array];
    
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"ownerSearchs"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [_ownerSearchs addObjectsFromArray:array];
    
    return _ownerSearchs;
    
}

- (NSMutableArray *)ownerIds {
    
    if (_ownerIds) {
        return _ownerIds;
    }
    
    _ownerIds = [NSMutableArray array];
    
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"ownerIds"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [_ownerIds addObjectsFromArray:array];
    
    return _ownerIds;
}

- (void) updateOwnerSearchs {
    
    [[NSUserDefaults standardUserDefaults] setObject:self.ownerSearchs forKey:@"ownerSearchs"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

- (void) updateOwnerIds {
    
    [[NSUserDefaults standardUserDefaults] setObject:self.ownerIds forKey:@"ownerIds"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

//单元格可移动
- (BOOL)collectionView:(UICollectionView *)collectionView canMoveItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        return YES;
    }
    return YES;
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {
    
    //开始索引
    NSInteger start = sourceIndexPath.row;
    NSInteger end = destinationIndexPath.row;
    
    //移动前的值
//    id startName = self.ownerSearchs[start];
//    id startId = self.ownerIds[start];
//    
//    id endName = self.ownerSearchs[end];
//    id endId = self.ownerIds[end];
    
    [self.ownerSearchs exchangeObjectAtIndex:start withObjectAtIndex:end];
    
    [self.ownerIds exchangeObjectAtIndex:start withObjectAtIndex:end];
    
    [self updateOwnerSearchs];
    [self updateOwnerIds];
    
    [collectionView reloadData];
}

- (void) moveAction:(UIPanGestureRecognizer *) pan {
    
    switch (pan.state) {
        case UIGestureRecognizerStateBegan:
            //通过手势获取要移动的cell的索引值
            [_collectionView beginInteractiveMovementForItemAtIndexPath:[_collectionView indexPathForItemAtPoint:[pan locationInView:pan.view]]];
            
            break;
            
        case UIGestureRecognizerStateChanged:
        
            //更新Cell
            [_collectionView updateInteractiveMovementTargetPosition:[pan locationInView:pan.view]];
            
            break;
            
        case UIGestureRecognizerStateEnded:
            
            //结束移动
            [_collectionView endInteractiveMovement];
            
            break;
            
        default:
            //取消移动
            [_collectionView cancelInteractiveMovement];
            
            break;
    }


    
}


@end
