//
//  WebController.h
//  Project3
//
//  Created by mac1 on 16/9/11.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ContentTableViewController.h"

typedef void (^updateYFScrollViewBlock)(NSString *channelName,ContentTableViewController *ctrl);

@interface WebController : UIViewController

//景点数据数组
@property (nonatomic, strong) NSDictionary *channelDataDic;

@property (nonatomic, strong) UITableView *tableView;


@property (nonatomic, copy) updateYFScrollViewBlock updateBlock;

@end
