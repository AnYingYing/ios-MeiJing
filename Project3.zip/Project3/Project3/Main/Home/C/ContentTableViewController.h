//
//  ContentTableViewController.h
//  Project3
//
//  Created by mac1 on 16/9/8.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HomeLayout.h"

@interface ContentTableViewController : UITableViewController

@property(nonatomic, strong)  HomeLayout *layout;
//景点id
@property (nonatomic, copy) NSString *channelId;
//景点名
@property (nonatomic, copy) NSString *channelName;
//景点
@property (nonatomic, copy) NSString *urlString;

@property (nonatomic, assign) BOOL isLoading;

@property (nonatomic, assign) NSInteger currentPage;

- (void) load;

@end
