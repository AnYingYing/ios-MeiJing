//
//  ContentTableViewController.m
//  Project3
//
//  Created by mac1 on 16/9/8.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "ContentTableViewController.h"


#import "DataSource.h"
#import "SenceModel.h"
#import "HomeModel.h"
#import "channelModel.h"

#import "HTUrlDic.h"


#import "HTDataService.h"

#import "MJRefresh.h"

#import "HomeViewCell.h"


@interface ContentTableViewController ()


//请求头
@property (nonatomic, strong) NSDictionary *requestHeadDic;

@property (nonatomic, strong) NSMutableArray *normalNewsArray;


@end

@implementation ContentTableViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    

}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.backgroundColor = [UIColor whiteColor];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"HomeViewCell" bundle:nil] forCellReuseIdentifier:@"cellId"];
    
    [self setupRefresh];
}



#pragma mark --private Method--初始化刷新控件
-(void)setupRefresh {
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        [self loadNewData];
        
    }];

    

    self.tableView.footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
        [self loadOldData];
    }];
    
}

#pragma mark --private Method--下拉刷新数据
- (void)loadNewData {
    
    
    [self fetchNewNormalNews];
}

#pragma mark --private Method--获取最新的普通新闻数据
-(void)fetchNewNormalNews {
    HomeLayout *layout = self.normalNewsArray.firstObject;
    channelModel *model = [[channelModel alloc] init];
    model.channelId = self.channelId;
    model.channelName = self.channelName;
    NSLog(@"%@",self.channelName);
    model.title = @"，";
    model.page = 1;
    //model.recentTime = layout.model.date;
    
    
    
    //景点URL处理（拼接URL）
    
    
    //http://a1.go2yd.com/Website/channel/news-list-for-channel?platform=1&cv=3.1.8&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&cend=50&dc=0&infinite=true&refresh=1&appid=meijing&channel_id=13004897306&cstart=0&version=010911&net=wifi
    NSString *fullUrlStr = [NSMutableString string];
    
//    NSString *urlStr1 = @"http://a1.go2yd.com/Website/channel/news-list-for-channel?dc=0&platform=1&infinite=true&cstart=0&cend=30&appid=meijing&cv=3.1.8&refresh=1&channel_id=";
    
    
    
    NSString *urlStr1 = @"http://a1.go2yd.com/Website/channel/news-list-for-channel?platform=1&cv=3.1.8&fields=docid&fields=date&fields=image&fields=image_urls&fields=like&fields=source&fields=title&fields=url&fields=comment_count&fields=up&fields=down&cend=50&dc=0&infinite=true&refresh=1&appid=meijing&channel_id=";
    
    NSString *urlStr2 = model.channelId;
//    NSString *urlStr2 = @"13004897306";
    
    NSString *urlStr3 = @"&cstart=0&version=010911&net=wifi";
    
    fullUrlStr = [NSString stringWithFormat:@"%@%@%@",urlStr1,urlStr2,urlStr3];
    
    NSLog(@"%@",fullUrlStr);
    
    //请求数据
    [HTDataService getWithURL:fullUrlStr params:nil headerField:[self.requestHeadDic mutableCopy] comPletionBlock:^(id data) {
        
        
        NSMutableArray *results = data[@"result"];
        
        
        //存储HomeLayout
        NSMutableArray *contentLayouts = [NSMutableArray array];
        
        for (NSDictionary *dic in results) {
            HomeModel *model = [[HomeModel alloc] init];
            [model setValueForPropertyWithDic:dic];
            HomeLayout *layout = [[HomeLayout alloc] init];
            layout.model = model;
            
            if ([layout.model.ctype isEqualToString:@"news"]) {
                [contentLayouts addObject:layout];
            }
            
        }
        
        
        
        self.normalNewsArray = contentLayouts;
        
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
        
    }];
    
    
//    [htda TTNormalNewsWithParameters:parameters success:^(NSMutableArray *array) {
//        self.normalNewsArray = array;
//        [SVProgressHUD dismiss];
//        [self.tableView reloadData];
//        [self.tableView.mj_header endRefreshing];
//    } failure:^(NSError *error) {
//        [SVProgressHUD dismiss];
//        [SVProgressHUD showErrorWithStatus:@"加载失败！"];
//        [self.tableView.mj_header endRefreshing];
//        [self.tableView reloadData];
//    }];
    
}

#pragma mark --private Method--上拉刷新数据
-(void)loadOldData {
    
    HomeLayout *layout = self.normalNewsArray.lastObject;
    if (self.currentPage >= layout.allPages) {
        [self.tableView.footer endRefreshingWithNoMoreData];
        return;
    }
    NSInteger currenpage = self.currentPage +1;
    channelModel *model = [[channelModel alloc] init];
    model.channelId = self.channelId;
    model.channelName = self.channelName;
    model.title = @":";
    model.page = currenpage;
    //model.remoteTime = news.createdtime;
    
    
    
    
    
    //请求数据
    [HTDataService getWithURL:model.channelId params:nil headerField:[self.requestHeadDic mutableCopy] comPletionBlock:^(id data) {
        
        
        NSMutableArray *results = data[@"result"];
        
        
        
        //存储HomeLayout
        NSMutableArray *contentLayouts = [NSMutableArray array];
        
        for (NSDictionary *dic in results) {
            HomeModel *model = [[HomeModel alloc] init];
            [model setValueForPropertyWithDic:dic];
            HomeLayout *layout = [[HomeLayout alloc] init];
            layout.model = model;

            if ([layout.model.ctype isEqualToString:@"news"]) {
                [contentLayouts addObject:layout];
            }
        }
        
        
        [self.normalNewsArray addObjectsFromArray:contentLayouts];
        [self.tableView reloadData];
        [self.tableView.footer endRefreshing];
        

        
    }];
    
    
//    [TTDataTool TTNormalNewsWithParameters:parameters success:^(NSMutableArray *array) {
//        [self.normalNewsArray addObjectsFromArray:array];
//        [self.tableView reloadData];
//        [self.tableView.mj_footer endRefreshing];
//        [SVProgressHUD dismiss];

//        
//    } failure:^(NSError *error) {
//        [SVProgressHUD dismiss];
//        [SVProgressHUD showErrorWithStatus:@"加载失败！"];
//        [self.tableView.mj_footer endRefreshing];
//        [self.tableView reloadData];
//    }];
    
}




- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.normalNewsArray.count;
    
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeLayout *layout = [[HomeLayout alloc] init];
    layout = self.normalNewsArray[indexPath.row];
    return layout.cellHeight;
    
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
    HomeViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId" forIndexPath:indexPath];
    
    HomeLayout *layout = self.normalNewsArray[indexPath.row];
    
    cell.layout = layout;
    
    cell.backgroundColor = [UIColor whiteColor];
    
    return cell;
}

#pragma mark --单元格的点击事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
        HomeLayout *layout = self.normalNewsArray[indexPath.row];
    
    
    
        if (layout.model.url) {
            NSURL *url = [NSURL URLWithString:layout.model.url];
            //NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
    
            //创建一个网页界面
            [self createWebPageWithChannelUrl:url];
            

            
            
        }
    
}

//创建web界面
- (void) createWebPageWithChannelUrl:(NSURL *)url {
    //创建web和相关控制器
    UIWebView *web = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [web loadRequest:request];
    
    UIViewController *webVC = [[UIViewController alloc] init];
    
    [webVC.view addSubview:web];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webVC];
    
    //创建左上角返回barButtonItem
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(0, 0, 45, 45);
    
    [button setTitle:@"返回" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    webVC.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    self.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    
    //弹出模态视图
    [self presentViewController:nav animated:YES completion:nil];
    
}

- (void) backAction {
    //关闭模态视图
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark --懒加载--normalNewsArray
-(NSMutableArray *)normalNewsArray {
    if (!_normalNewsArray) {
        _normalNewsArray = [NSMutableArray array];
    }
    return _normalNewsArray;
}

#pragma mark --懒加载--请求头
-(NSDictionary *)requestHeadDic {
    if (!_requestHeadDic) {
        _requestHeadDic = @{
                            @"Accept-Encoding":@"gzip, deflate",
                            @"Cookie":@"JSESSIONID=yR-ln5cCJaGn2Va63UK55A"
                            };
        //JSESSIONID=yR-ln5cCJaGn2Va63UK55A
    }
    return _requestHeadDic;
}

//判断是否第一次进入
- (void) load {
    //开始刷新动画
    [self.tableView.header beginRefreshing];
    
    //NSLog(@"%@---加载动画,刷新数据",self.channelName);
    
    self.isLoading = YES;

    
    
}


@end
