//
//  HomeController.m
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "HomeController.h"


#import "ContentTableViewController.h"

//collectionView的景点头视图
#import "ChannelsSectionHeaderView.h"

#import "ChannelCollectionViewCell.h"


//搜索控制器
#import "SearchController.h"

#import "UIView+HTUIView_EXT.h"

#define KScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define KScreenHeight ([UIScreen mainScreen].bounds.size.height)

@interface HomeController ()<YFLinkageScrollViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate>

//所有的景点名
@property (nonatomic, strong) NSMutableArray *allChannelsArray;

@property (nonatomic, strong) NSMutableDictionary *channelsUrlDictionary;


//设置单元格是否摇动
@property (nonatomic, assign) BOOL isCellShouldShake;

@end


static NSString * const collectionCellID = @"ChannelCollectionCell";
static NSString * const collectionViewSectionHeaderID = @"ChannelCollectionHeader";


@implementation HomeController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    /*
        如果设置此属性，在弹出的模态视图控制器也是 NavigationController时，导航栏会发生偏移
     self.navigationController.navigationBar.translatesAutoresizingMaskIntoConstraints = NO;
     */
    
    
    NSLog(@"沙盒路径%@",NSHomeDirectory());
    
    
    _yfScrollView = [[YFLinkageScrollView alloc] initWithFrame:CGRectMake(0, 64, KScreenWidth, KScreenHeight-64)];
    
    [self.view addSubview:_yfScrollView];
    
    [self config];
    
    [self setupCollectionView];
    
    [self createAddButton];
    //添加搜索方式
    [self createSearch];
    
    
    
}

- (void)config
{
    
    self.viewCtrls = [NSMutableArray array];
    
    for (int i=0; i<self.currentChannelsArray.count; i++) {
        ContentTableViewController *tabVC = [[ContentTableViewController alloc] init];
        
        //对应景点的名
        tabVC.channelName= self.currentChannelsArray[i];
        //对应景点的URL的channel_id
        tabVC.channelId = self.channelsUrlDictionary[tabVC.channelName];
        
        tabVC.currentPage = i;
        
        [self.viewCtrls addObject:tabVC];
    }
    
    [self.yfScrollView configWithScrolltagArray:self.currentChannelsArray visibleCount:5 sliderType:YFSliderTypeBottom contentScrollItem:self.viewCtrls];
    
    
    
    self.yfScrollView.rotateVisibleCount = 5;
    self.yfScrollView.tagScroll.backgroundColor = [UIColor whiteColor];
    
//    self.yfScrollView.tagScroll.backgroundColor = [UIColor colorWithRed:42.0/255 green:169.0/255 blue:151.0/255 alpha:1];
    //    self.yfScrollView.isMoveToVisible = YES;
    self.yfScrollView.sliderWidthScale = .4;
    self.yfScrollView.delegate = self;
    self.yfScrollView.sliderColor = [UIColor redColor];
}

// 创建加号按钮
- (void)createAddButton{
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(KScreenWidth-45, 64, 40, 40);
    
    [button setImage:[UIImage imageNamed:@"channel_search_add_icon@2x"] forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(showOrHiddenAddChannelsCollectionView:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button];
    
}

#pragma mark - YFLinkageScrollViewDelegate

- (void)yfScrollViewOutOfRight:(CGFloat)value
{
    //NSLog(@"%f",value);
}

- (void)yfScrollViewOutOfLeft:(CGFloat)value
{
    //NSLog(@"%f",value);
}

- (void)yfScrollViewChangeCurrentIndex:(NSInteger)currentIndex item:(id)item
{
    static BOOL isFirst = YES;
    
    NSLog(@"当前是第%ld页",currentIndex);
    
    if ([item isKindOfClass:[ContentTableViewController class]]) {
        ContentTableViewController *vc = (ContentTableViewController *)self.viewCtrls[currentIndex];
        
        if (isFirst) {
            
            NSLog(@"进入首页");
            
            //推荐页加载数据
            [vc load];
            
            isFirst = NO;
            
        }
    
        if (vc.isLoading) {
            NSLog(@"当前页面早已刷新");
            return;
        } else {
            
            //每个页面第一次进入刷新数据
            [vc load];
            
        }
        
    }

    
}


#pragma mark --private Method--懒加载currentChannelsArray
-(NSMutableArray *)currentChannelsArray {
    if (!_currentChannelsArray) {
        _currentChannelsArray = [NSMutableArray array];
        NSArray *array = [[NSUserDefaults standardUserDefaults] arrayForKey:@"currentChannelsArray"];
        [_currentChannelsArray addObjectsFromArray:array];
        if (_currentChannelsArray.count == 0) {
            [_currentChannelsArray addObjectsFromArray:@[@"国内游", @"南海",@"古镇",@"古城",@"北京旅游"]];
            [self updateCurrentChannelsArrayToDefaults];
        }
    }
    return _currentChannelsArray;
}

#pragma mark --懒加载--remainChannelsArray
-(NSMutableArray *)remainChannelsArray {
    if (!_remainChannelsArray) {
        _remainChannelsArray = [NSMutableArray array];
        [_remainChannelsArray addObjectsFromArray:self.allChannelsArray];
        [_remainChannelsArray removeObjectsInArray:self.currentChannelsArray];
    }
    return _remainChannelsArray;
}



#pragma mark --懒加载--allChannelsArray
-(NSMutableArray *)allChannelsArray {
    if (!_allChannelsArray) {
        _allChannelsArray = [NSMutableArray array];
        NSArray *tempArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"allChannelsArray"];
        [_allChannelsArray addObjectsFromArray:tempArray];
        if (_allChannelsArray.count == 0) {
            [_allChannelsArray addObjectsFromArray:@[@"国内游",@"南海",@"凤凰古城",@"山西旅游",@"山东旅游",@"台湾旅游",@"青海旅游",@"四川旅游",@"西藏旅游",@"江苏旅游",@"澳门旅游",@"西塘旅游",@"乌镇旅游",@"云南旅游",@"海南旅游",@"香港旅游",@"北京旅游",@"镇远古镇",@"古镇",@"古城"]];
            [[NSUserDefaults standardUserDefaults] setObject:_allChannelsArray forKey:@"allChannelsArray"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        
    }
    return _allChannelsArray;
}



#pragma mark --懒加载--channelsUrlDictionary
-(NSMutableDictionary *)channelsUrlDictionary {
    if (!_channelsUrlDictionary) {
        _channelsUrlDictionary = [NSMutableDictionary dictionary];
        NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryForKey:@"channelsUrlDictionary"];
        [_channelsUrlDictionary addEntriesFromDictionary:dict];
        if (_channelsUrlDictionary.count == 0) {
            NSDictionary *tempDictionary = @{
                         @"国内游": @"4294628615",
                         @"南海": @"4311049767",
                         @"凤凰古城": @"4294628663",
                         @"山西旅游": @"4340628727",
                         @"山东旅游": @"4340628231",
                         @"台湾旅游": @"4340627687",
                         @"青海旅游": @"4340620887",
                         @"四川旅游": @"4340620727",
                         @"西藏旅游": @"4340620167",
                         @"江苏旅游": @"4340620039",
                         @"澳门旅游": @"4294628775",
                         @"西塘旅游": @"4294628711",
                         @"乌镇旅游": @"4294628695",
                         @"云南旅游": @"4340614535",
                         @"海南旅游": @"4294628791",
                         @"香港旅游": @"4294628759",
                         @"北京旅游": @"4294628743",
                         @"镇远古镇": @"4294628679",
                         @"古镇": @"4294628647",
                         @"古城": @"4294628631",
                                             };
            [_channelsUrlDictionary addEntriesFromDictionary:tempDictionary];
            [[NSUserDefaults standardUserDefaults] setObject:_channelsUrlDictionary forKey:@"channelsUrlDictionary"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
    }
    return _channelsUrlDictionary;
}



//-------------初始化创建需要弹出的collectionView-------------
#pragma mark --private Method--初始化点击加号按钮弹出的新闻频道编辑的CollectionView
-(void)setupCollectionView {
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    flowLayout.headerReferenceSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 35);//头部
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 100, 0, 0) collectionViewLayout:flowLayout];
    //self.collectionView.backgroundColor = [UIColor yellowColor];
    
    self.collectionView = collectionView;
    collectionView.backgroundColor = [UIColor whiteColor];
    collectionView.alpha = 0.98;
    [self.view addSubview:collectionView];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    
    [collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ChannelCollectionViewCell class]) bundle:nil] forCellWithReuseIdentifier:collectionCellID];
 
    [collectionView registerClass:[ChannelsSectionHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:collectionViewSectionHeaderID];
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的cell是否能被选中
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的组标题View
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    ChannelsSectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:collectionViewSectionHeaderID forIndexPath:indexPath];
    if (indexPath.section == 0) {
        headerView.titleLabel.text = @"已添加栏目 (点击跳转，长按删除)";
        
    }else if (indexPath.section == 1) {
        headerView.titleLabel.text = @"可添加栏目 (点击添加)";
    }
    return headerView;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的组数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的每一组对应的cell个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return self.currentChannelsArray.count;
    } else {
        return self.remainChannelsArray.count;
    }
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每个indexpath对应的cell
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    ChannelCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectionCellID forIndexPath:indexPath];
    
    cell.backgroundColor = [UIColor cyanColor];
    
    cell.delegate = self;
    [cell stopShake];
    cell.deleteButton.hidden = YES;
    if (indexPath.section == 0) {
        
        cell.channelName = self.currentChannelsArray[indexPath.row];
        cell.theIndexPath = indexPath;
        if (self.isCellShouldShake == YES) {
            [cell startShake];
            cell.deleteButton.hidden = NO;
        
        }
    
    } else {
        cell.channelName = self.remainChannelsArray[indexPath.row];
    }
    
    return cell;

}

#pragma mark --UICollectionViewDataSource-- 返回每个UICollectionViewCell发Size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat kDeviceWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat kMargin = 10;
    return CGSizeMake((kDeviceWidth - 5*kMargin)/4, 40);
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每一组的外边距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每个item之间的最小间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}

#pragma mark --UICollectionViewDataSource-- 设置collectionView每个item可移动
- (BOOL)collectionView:(UICollectionView *)collectionView canMoveItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        return YES;
    }
    
    return NO;
}

#pragma mark --UICollectionViewDataSource-- 设置collectionView每个item移动 会调用的方法
- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {
    
    //移动开始位置
    NSInteger from = sourceIndexPath.row;
    //移动结束位置
    NSInteger to = destinationIndexPath.row;
    //获取数组开始位置的数据
    id fromValue = [self.currentChannelsArray objectAtIndex:from];
    id toValue = [self.currentChannelsArray objectAtIndex:to];
    //将他们的数据相互替代
    [self.currentChannelsArray replaceObjectAtIndex:from withObject:toValue];
    [self.currentChannelsArray replaceObjectAtIndex:to withObject:fromValue];
    
    [self.yfScrollView exchangeAtIndex:from withIndex:to];
    
    [self.collectionView reloadData];
}

//-------------点击加号弹出collectionView-------------
#pragma mark --TTTopChannelContianerViewDelegate--点击加号按钮，展示或隐藏编辑新闻频道CollectionView
- (void)showOrHiddenAddChannelsCollectionView:(UIButton *)button {
    
    if (button.selected == NO) {//点击状态正常的加号buuton，显示编辑频道CollectionView
        [self shouldShowChannelsEditCollectionView:YES];
    } else {//点击状态为已经被选中的加号buuton，显示编辑频道CollectionView
        [self shouldShowChannelsEditCollectionView:NO];
    }
    button.selected = !button.selected;
}

#pragma mark --private Method--显示或隐藏点击加号按钮弹出的新闻频道编辑的CollectionView
-(void)shouldShowChannelsEditCollectionView:(BOOL)value {
    
    if (value == YES) {//显示新闻频道编辑View
        [UIView animateWithDuration:0.25 animations:^{
            
            self.collectionView.frame = CGRectMake(0, 100, KScreenWidth, KScreenHeight-100);
            
        }];
        self.tabBarController.tabBar.hidden = YES;
        
    } else {//隐藏新闻频道编辑View
        [UIView animateWithDuration:0.25 animations:^{
            
            self.collectionView.frame = CGRectMake(0, 100, 0, 0);
            
        }];
        
        self.tabBarController.tabBar.hidden = NO;
        
    }
    
}

//-----------------点击单元格调用的方法-------------------

#pragma mark --UICollectionViewDelegate-- 点击了某个UICollectionViewCell
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {//点击的是第一组的cell，跳转到相应的新闻频道
        
        [self.yfScrollView setCurrentIndex:indexPath.row animated:YES TagAnimated:YES];
        
    }else {//点击的是第二组的cell，新增自控制器
        [self.currentChannelsArray addObject:self.remainChannelsArray[indexPath.row]];
        [self.remainChannelsArray removeObjectAtIndex:indexPath.row];
        [self updateCurrentChannelsArrayToDefaults];
        //新增自控制器
        ContentTableViewController *viewController = [[ContentTableViewController alloc] init];
        viewController.channelName = self.currentChannelsArray.lastObject;
        viewController.channelId = self.channelsUrlDictionary[viewController.channelName];
        [self.viewCtrls addObject:viewController];
        //新增新闻频道
        [self.yfScrollView addTagTitle:self.currentChannelsArray.lastObject contentItem:viewController];

        [self.collectionView reloadData];
    }
}

#pragma mark --ChannelCollectionViewCellDelegate-- 长按第一组某个ChannelCollectionViewCell的回调方法
- (void)didLongPressAChannelCell {
    
    [self shouldStartShakingCellsWithValue:YES];
    [self.collectionView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector (tapCollectionView)]];
    
    [self.collectionView addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveItem:)]];
    
}

#pragma mark --ChannelCollectionViewCellDelegate-- 点击第一组ChannelCollectionViewCell左上角的删除按钮的回调方法
- (void)deleteTheCellAtIndexPath:(NSIndexPath *)indexPath {
    [self shouldStartShakingCellsWithValue:NO];
    NSInteger index = indexPath.row;
    [self.remainChannelsArray addObject:self.currentChannelsArray[index]];
    [self.currentChannelsArray removeObjectAtIndex:index];
    [self updateCurrentChannelsArrayToDefaults];
    [self.childViewControllers[index] removeFromParentViewController];
    [self.viewCtrls removeObjectAtIndex:index];
    
    [self.yfScrollView removeContentAtIndex:index];
    
    [self.yfScrollView updateTagArr:self.currentChannelsArray contentArr:self.viewCtrls];
    
    [self.collectionView reloadData];
    [self shouldStartShakingCellsWithValue:YES];
    
}

//#pragma mark --TTTopChannelContianerViewDelegate--选择了某个新闻频道，更新scrollView的contenOffset
//- (void)chooseChannelWithIndex:(NSInteger)index {
//    
//    [self.yfScrollView setCurrentIndex:index animated:YES TagAnimated:YES];
//    
//}

#pragma mark --private Method--collectionView添加手势识别器后,轻点collectionView会调用的方法
- (void)tapCollectionView {
    [self shouldStartShakingCellsWithValue:NO];
    [self.collectionView removeGestureRecognizer:self.collectionView.gestureRecognizers.lastObject];
    [self.collectionView reloadData];
}

#pragma mark --private Method--是否应该开始抖动，如果Value为YES那么会开始抖动，Value为NO会停止抖动
- (void)shouldStartShakingCellsWithValue:(BOOL)value {
    self.isCellShouldShake= value;
    [self.collectionView reloadData];
}


#pragma mark - 手势响应事件
-(void)moveItem:(UIPanGestureRecognizer *)gesture{
    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
            // 通过手势来获取要移动的Cell的索引
            [_collectionView beginInteractiveMovementForItemAtIndexPath:[_collectionView indexPathForItemAtPoint:[gesture locationInView:gesture.view]]];
            break;
        case UIGestureRecognizerStateChanged:
            // 更新移动的Cell的位置
            [_collectionView updateInteractiveMovementTargetPosition:[gesture locationInView:gesture.view]];
            break;
        case UIGestureRecognizerStateEnded:
            // 手势动作完成后，结束交互式移动
            [_collectionView endInteractiveMovement];
            break;
        default:
            // 取消交互运动
            [_collectionView cancelInteractiveMovement];
            break;
    }
}

#pragma mark --private Method--存储更新后的currentChannelsArray到偏好设置中
-(void)updateCurrentChannelsArrayToDefaults{
    [[NSUserDefaults standardUserDefaults] setObject:self.currentChannelsArray forKey:@"currentChannelsArray"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


#pragma mark - 创建导航栏搜索
- (void) createSearch {
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, KScreenWidth-20, 44-10)];
    self.navigationItem.titleView = view;
    
    UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, 70, 44-10)];
    lab.text = @"美景中国";
    [view addSubview:lab];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.contentMode = UIViewContentModeScaleToFill;
    
    button.frame = CGRectMake(lab.right, 0, KScreenWidth-lab.frame.size.width-20, 44-10);
    
    [button setImage:[UIImage imageNamed:@"search_bg@2x"] forState:UIControlStateNormal];
    
    
    [button addTarget:self action:@selector(searchAction) forControlEvents:UIControlEventTouchUpInside];
    
    [view addSubview:button];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 0, button.frame.size.width, button.frame.size.height)];
    label.text = @"搜索你感兴趣的";
    [button addSubview:label];
    
}

- (void) searchAction {
    
    SearchController *search = [[SearchController alloc] init];

    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:search];
    
    [self presentViewController:nav animated:YES completion:nil];
    
    search.updateBlock = ^(NSString *channelName,ContentTableViewController *ctrl) {
        
        //[self.currentChannelsArray insertObject:channelName atIndex:0];
        [self.currentChannelsArray addObject:channelName];
        //[self.remainChannelsArray removeObjectAtIndex:indexPath.row];
        [self updateCurrentChannelsArrayToDefaults];
        //新增自控制器
        //[self.viewCtrls insertObject:ctrl atIndex:0];
        [self.viewCtrls addObject:ctrl];
        //新增新闻频道
        //[self.yfScrollView addTagTitle:channelName contentItem:ctrl atIndex:0];
        [self.yfScrollView addTagTitle:channelName contentItem:ctrl];
    
        [ctrl load];
        [self.collectionView reloadData];
    };
}




@end
