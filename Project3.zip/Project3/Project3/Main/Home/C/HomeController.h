//
//  HomeController.h
//  Project3
//
//  Created by mac1 on 16/9/5.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "BaseViewController.h"

#import "YFLinkageScrollView.h"

@interface HomeController : BaseViewController

//当前关注的景点名
@property (nonatomic, strong) NSMutableArray *currentChannelsArray;
//未关注的景点名
@property (nonatomic, strong) NSMutableArray *remainChannelsArray;


@property (nonatomic, strong)YFLinkageScrollView *yfScrollView;

@property (nonatomic, strong) NSMutableArray *viewCtrls;

@property (nonatomic, weak) UICollectionView *collectionView;

-(void)updateCurrentChannelsArrayToDefaults;
@end
